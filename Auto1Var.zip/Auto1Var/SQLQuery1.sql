USE [master]
GO
/****** Object:  Database [Drivers]    Script Date: 07.02.2022 13:16:07 ******/
CREATE DATABASE [Drivers]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'GIBBD_kur', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\GIBBD_kur.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'GIBBD_kur_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\GIBBD_kur_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [Drivers] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Drivers].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Drivers] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Drivers] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Drivers] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Drivers] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Drivers] SET ARITHABORT OFF 
GO
ALTER DATABASE [Drivers] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [Drivers] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Drivers] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Drivers] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Drivers] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Drivers] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Drivers] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Drivers] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Drivers] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Drivers] SET  DISABLE_BROKER 
GO
ALTER DATABASE [Drivers] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Drivers] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Drivers] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Drivers] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Drivers] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Drivers] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Drivers] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Drivers] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Drivers] SET  MULTI_USER 
GO
ALTER DATABASE [Drivers] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Drivers] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Drivers] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Drivers] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Drivers] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Drivers] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [Drivers] SET QUERY_STORE = OFF
GO
USE [Drivers]
GO
/****** Object:  Table [dbo].[Car]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Car](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[VIN] [nvarchar](200) NOT NULL,
	[ModelId] [int] NOT NULL,
	[Year] [int] NOT NULL,
	[Weight] [int] NOT NULL,
	[Color] [int] NOT NULL,
	[EngineType] [int] NOT NULL,
	[TypeOfDrive] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Cars] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarsManufacturer]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarsManufacturer](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_CarsManufacturer] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarsModel]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarsModel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ManufacturerId] [int] NOT NULL,
 CONSTRAINT [PK_CarsModel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Categories]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ChangedStatus]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ChangedStatus](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LicenseId] [int] NOT NULL,
	[StatusId] [int] NOT NULL,
	[Comment] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_ChangedStatus] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DriverOrCar]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DriverOrCar](
	[DriverId] [int] NOT NULL,
	[CarId] [int] NOT NULL,
	[Nothing] [nvarchar](5) NULL,
 CONSTRAINT [PK_DriverOrCar] PRIMARY KEY CLUSTERED 
(
	[DriverId] ASC,
	[CarId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DriverOrLicense]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DriverOrLicense](
	[DriverId] [int] NOT NULL,
	[LicenseId] [int] NOT NULL,
	[Nothing] [nvarchar](5) NULL,
 CONSTRAINT [PK_DriverOrLicense] PRIMARY KEY CLUSTERED 
(
	[DriverId] ASC,
	[LicenseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Drivers]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Drivers](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Surname] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Middlename] [nvarchar](50) NOT NULL,
	[Passport] [nvarchar](13) NOT NULL,
	[Town] [nvarchar](50) NOT NULL,
	[Address] [nvarchar](200) NOT NULL,
	[Company] [nvarchar](50) NOT NULL,
	[Jobname] [nvarchar](50) NOT NULL,
	[Phone] [nvarchar](20) NOT NULL,
	[Email] [nvarchar](100) NOT NULL,
	[Photo] [nvarchar](max) NULL,
	[Comment] [nvarchar](max) NULL,
 CONSTRAINT [PK_Drivers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[License]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[License](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LicenseDate] [date] NOT NULL,
	[ExpireDate] [date] NOT NULL,
	[License] [nvarchar](11) NOT NULL,
	[StatusId] [int] NOT NULL,
 CONSTRAINT [PK_License] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LicenseOrCategories]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LicenseOrCategories](
	[LicenseId] [int] NOT NULL,
	[CategoriesId] [int] NOT NULL,
	[Nothing] [nvarchar](5) NULL,
 CONSTRAINT [PK_LicenseOrCategories] PRIMARY KEY CLUSTERED 
(
	[LicenseId] ASC,
	[CategoriesId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Status]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Status](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](30) NOT NULL,
 CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 07.02.2022 13:16:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[Id] [int] NOT NULL,
	[Login] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](50) NOT NULL,
	[PinCode] [int] NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Car] ON 
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (1, N'WBAKG7C54DJ746310', 1, 2009, 1794, 116, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (2, N'JN1CV6APXCM884333', 1, 2018, 1523, 118, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (3, N'2C4RDGCG2FR292116', 2, 1994, 1750, 120, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (4, N'2HNYD2H46CH088623', 1, 1991, 1799, 127, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (5, N'KNAFU5A29D5373281', 52, 2016, 1791, 128, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (6, N'1FTMF1E84AK129978', 3, 2006, 1637, 129, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (7, N'WBAKE5C5XCJ498380', 5, 2016, 1483, 133, 1, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (8, N'JTHFF2C27F2931205', 5, 2008, 1574, 145, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (9, N'WBABW33455P972485', 5, 1996, 1753, 170, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (10, N'5FNRL5H2XCB183642', 5, 2009, 1409, 180, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (11, N'JTEBU4BF9DK234908', 5, 2018, 1729, 201, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (12, N'1G6DM577280903075', 6, 2010, 1711, 202, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (13, N'1GYFC43539R480716', 5, 2001, 1748, 203, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (14, N'1N6AA0CJ3FN926889', 6, 1995, 1761, 204, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (15, N'2T1BURHE6EC080516', 4, 2009, 1574, 210, 3, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (16, N'WBA3T7C57FP608583', 51, 2002, 1495, 215, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (17, N'5FNYF3H48FB049614', 7, 2004, 1569, 217, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (18, N'WVWGD7AJ7EW053317', 9, 2008, 1705, 223, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (19, N'JM1NC2LF0E0131767', 9, 1998, 1585, 228, 3, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (20, N'1FTSW2A50AE633032', 9, 1993, 1493, 233, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (21, N'2C3CCAKT5CH834724', 9, 2019, 1633, 235, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (22, N'1FMJU1F5XAE067185', 88, 2004, 1557, 236, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (23, N'5TFBY5F18AX095253', 29, 1994, 1539, 245, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (24, N'WAUVC68E55A439175', 16, 2005, 1471, 276, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (25, N'3D73M4CL0AG485600', 12, 2013, 1500, 277, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (26, N'3D73M3CL4BG992821', 32, 1998, 1750, 280, 1, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (27, N'2HNYD18214H913977', 26, 1992, 1586, 286, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (28, N'1G6DJ5E34C0750992', 21, 2005, 1455, 295, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (29, N'3VW217AU7FM147306', 21, 2004, 1795, 311, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (30, N'1FMJU1J56AE113733', 21, 1997, 1445, 340, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (31, N'JN1CV6AP0CM243398', 69, 1999, 1433, 345, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (32, N'1FTWW3B5XAE601405', 71, 2000, 1459, 370, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (33, N'WBASN2C55AC523024', 71, 2000, 1504, 371, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (34, N'NM0KS9BNXBT830533', 71, 1991, 1401, 373, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (35, N'1C4RJEAG6FC571030', 71, 2015, 1677, 377, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (36, N'WBS3R9C51FF196091', 73, 2001, 1596, 383, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (37, N'1G4HD57238U904159', 72, 1993, 1583, 385, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (38, N'1HGCP2E46AA778977', 72, 2019, 1417, 387, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (39, N'WAUBGAFB1AN276966', 72, 1992, 1423, 399, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (40, N'WAUDF48H97A496239', 72, 2002, 1652, 403, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (41, N'5UXFG83558L839159', 72, 2016, 1777, 406, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (42, N'1FMJK1J51AE558998', 11, 2000, 1426, 408, 3, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (43, N'SCFBF03B27G582917', 11, 2012, 1629, 415, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (44, N'WAUCFAFH0AN942677', 70, 2002, 1438, 416, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (45, N'JN8CS1MU3EM315101', 70, 1999, 1724, 417, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (46, N'1D7RE3BK7AS869215', 39, 1992, 1434, 425, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (47, N'5N1AA0NC5EN749211', 20, 1995, 1459, 427, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (48, N'3D7TT2CT1BG470774', 37, 2015, 1460, 428, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (49, N'WBA3V5C5XFP343527', 37, 1997, 1583, 445, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (50, N'1G6DE5E5XC0016413', 74, 1997, 1601, 446, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (51, N'1FTSF3A50AE770400', 74, 2006, 1505, 447, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (52, N'1FTEX1CM5BK565807', 74, 2009, 1518, 448, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (53, N'1G6AH5S31F0348385', 74, 1998, 1781, 449, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (54, N'1N4AB7APXDN538514', 74, 1999, 1404, 456, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (55, N'3C6LD4AT3CG450587', 74, 2012, 1744, 458, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (56, N'3GYFNCEY2BS887540', 74, 1994, 1468, 460, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (57, N'1GYS4FEJ9CR310756', 74, 2019, 1535, 464, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (58, N'WAUBFCFL8CN296660', 74, 1996, 1573, 480, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (59, N'2T1BURHE5EC940812', 74, 2018, 1679, 481, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (60, N'WAULT58EX5A470410', 40, 2016, 1604, 487, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (61, N'JN8AF5MR7ET518545', 38, 2013, 1614, 498, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (62, N'WAUAC48H96K683520', 34, 2011, 1649, 509, 1, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (63, N'WAUHGAFC8FN632100', 34, 2017, 1711, 601, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (64, N'WAUWFBFL6AA160138', 34, 2017, 1406, 602, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (65, N'WAUEH48H68K095273', 34, 2004, 1736, 626, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (66, N'WAUEH74F76N744161', 34, 1995, 1490, 628, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (67, N'1J4RG4GK7AC818854', 34, 2000, 1636, 640, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (68, N'KNADH4A36B6877082', 34, 2006, 1753, 670, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (69, N'3GYFNGEY9BS444647', 34, 2010, 1419, 671, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (70, N'WP0AB2A87FK108949', 34, 2006, 1791, 690, 1, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (71, N'3VWML7AJXEM569531', 27, 1993, 1472, 793, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (72, N'WBSBR93493P275260', 27, 2010, 1551, 795, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (73, N'1G6DP567750890960', 27, 2009, 1449, 798, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (74, N'1FTEW1CM3DF334371', 68, 2005, 1540, 963, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (75, N'WAUDH78E47A363910', 68, 1999, 1736, 101, 2, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (76, N'1C4RJEAG6CC011603', 28, 2009, 1692, 107, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (77, N'1G6AB5SA9D0113584', 41, 1991, 1665, 110, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (78, N'1N6BF0KM6FN922689', 42, 1993, 1725, 116, 1, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (79, N'WA1YL64B34N831763', 42, 1995, 1710, 118, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (80, N'WBAUP9C58AV223509', 75, 2011, 1562, 120, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (81, N'WAUHF98P96A724812', 31, 1991, 1512, 127, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (82, N'1FTEX1CM1BF296018', 30, 1992, 1638, 128, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (83, N'3LNDL2L33CR462059', 48, 2000, 1609, 129, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (84, N'19UUA66218A797800', 48, 2003, 1603, 133, 1, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (85, N'ZFBCFACH5FZ996096', 49, 1995, 1669, 145, 2, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (86, N'4T1BF1FK2EU831999', 49, 2015, 1468, 170, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (87, N'2G4WS55J341869989', 80, 2006, 1546, 180, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (88, N'1G6DN57U260742856', 59, 1995, 1608, 201, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (89, N'YV1382MW1A2097161', 59, 1997, 1757, 202, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (90, N'WA1LMAFE9DD722859', 35, 2004, 1505, 203, 3, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (91, N'1FAHP3E28CL132877', 55, 2003, 1651, 204, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (92, N'WBAUP7C52BV069773', 22, 1995, 1675, 210, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (93, N'1ZVBP8JZ2D5191071', 22, 1996, 1459, 215, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (94, N'3C63D2GL5CG863137', 62, 2011, 1576, 217, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (95, N'1G6KF57952U735337', 62, 1994, 1421, 223, 1, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (96, N'5XYKT3A62FG416932', 33, 2000, 1518, 228, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (97, N'WBANV1C59AC580740', 82, 2012, 1682, 233, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (98, N'WAUFGAFC6DN013144', 23, 2006, 1508, 235, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (99, N'3VWKX7AJ2DM808838', 24, 1995, 1475, 236, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (100, N'1G6DJ1E37D0628461', 46, 1990, 1768, 245, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (101, N'5FRYD4H97GB588815', 25, 1998, 1737, 276, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (102, N'SCBDU3ZA7CC107541', 25, 2005, 1680, 277, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (103, N'3VWF17AT3FM605285', 25, 1991, 1539, 280, 1, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (104, N'1LNHL9DK8EG585379', 63, 2003, 1757, 286, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (105, N'JN8AZ2KR3DT115699', 81, 2019, 1725, 295, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (106, N'JN1CV6FEXCM381103', 54, 2003, 1698, 301, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (107, N'1G6DH5E5XC0462438', 79, 2017, 1705, 302, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (108, N'TRURD38J381614210', 79, 1993, 1767, 307, 2, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (109, N'4T1BD1FK6FU133645', 79, 2018, 1668, 310, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (110, N'2T1BURHE4FC565514', 76, 2011, 1571, 311, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (111, N'5TDBW5G12FS063304', 76, 2004, 1783, 340, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (112, N'WAULFAFR3DA033269', 76, 2009, 1659, 345, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (113, N'1G6DK8ED9B0319764', 50, 1995, 1720, 370, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (114, N'3VW4A7AT6DM813925', 17, 2017, 1744, 371, 1, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (115, N'WVWAB7AJ0CW557264', 18, 2017, 1667, 373, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (116, N'4A31K2DF7BE138498', 17, 2016, 1745, 110, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (117, N'JN1AZ4EH7AM509399', 44, 2008, 1775, 116, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (118, N'2T3BFREV2EW071669', 45, 1992, 1779, 118, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (119, N'YV1612FH2D1519917', 45, 2008, 1769, 120, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (120, N'JH4KA96631C195497', 45, 1990, 1528, 127, 3, N'full drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (121, N'WBAEK13597C722490', 84, 1991, 1496, 128, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (122, N'1GYS3HKJ9FR278172', 83, 2011, 1420, 129, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (123, N'WAUD2AFD1EN207208', 56, 2013, 1763, 133, 2, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (124, N'WAULL44E35N431957', 56, 1992, 1460, 145, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (125, N'KNAFU6A20B5806571', 43, 2007, 1526, 170, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (126, N'SAJWA2GTXEM305896', 19, 1995, 1771, 180, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (127, N'WAULL44E95N690503', 14, 2017, 1601, 201, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (128, N'WAUGFAFC5DN926548', 47, 1992, 1663, 202, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (129, N'5TDBM5G19BS020076', 58, 2009, 1594, 203, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (130, N'3N1AB6AP7BL573385', 66, 1998, 1515, 204, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (131, N'5XYZT3LB7FG893235', 61, 2013, 1662, 210, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (132, N'JH4KC1F78EC530392', 78, 2004, 1718, 215, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (133, N'2G4WE587581834383', 65, 2004, 1577, 217, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (134, N'WAUDF48H98K345526', 67, 2008, 1469, 223, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (135, N'WBA3G7C54EF309612', 67, 2008, 1453, 228, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (136, N'1G6DD8E31E0169171', 52, 2016, 1633, 233, 1, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (137, N'YV1902FH3D1001332', 3, 2019, 1797, 235, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (138, N'3N1CN7AP5FL866147', 5, 2006, 1706, 236, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (139, N'YV4902NC8F1531985', 5, 2014, 1685, 245, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (140, N'KL4CJFSB9FB654370', 5, 1993, 1664, 276, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (141, N'JN1BV7APXFM374795', 5, 1994, 1756, 277, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (142, N'WAUAFAFH7EN465064', 5, 2000, 1534, 280, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (143, N'WAUVC68E33A401568', 6, 2006, 1716, 286, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (144, N'KMHTC6AD4EU662541', 5, 2000, 1610, 295, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (145, N'5UXFG43539L241999', 6, 2012, 1597, 301, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (146, N'1GYS3FEJ8CR664092', 4, 1996, 1701, 302, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (147, N'WBAKN9C51FD688174', 51, 2008, 1691, 307, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (148, N'5NMSG3AB7AH234028', 7, 2007, 1447, 310, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (149, N'SALAB2V67FA465605', 9, 2008, 1723, 311, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (150, N'JN1CY0APXAM160384', 9, 2007, 1722, 340, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (151, N'WBAUP7C58DV367411', 9, 2007, 1622, 345, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (152, N'WAUAFAFL0FN838290', 9, 2017, 1725, 370, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (153, N'1LNHL9EK9FG365197', 9, 2015, 1456, 371, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (154, N'YV1672MK0D2114467', 9, 2004, 1480, 373, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (155, N'WAUKG98E56A006286', 8, 2009, 1481, 377, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (156, N'SAJWA4EB7EL432469', 10, 2004, 1438, 383, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (157, N'3LNHL2GC0AR226381', 53, 1992, 1611, 385, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (158, N'WAUVFAFH7BN873285', 85, 2006, 1581, 387, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (159, N'SALAG2D47AA801263', 86, 1993, 1527, 399, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (160, N'WBSWD9C57AP228332', 86, 2007, 1426, 403, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (161, N'1FTWW3B53AE587413', 86, 2007, 1674, 406, 3, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (162, N'4USBU53567L936239', 87, 1991, 1596, 408, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (163, N'1FTWF3D57AE486873', 87, 2014, 1656, 415, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (164, N'2G4WD582261511218', 88, 1994, 1731, 416, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (165, N'WBAGN83515D855874', 29, 2005, 1763, 417, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (166, N'2C3CDXL97FH493561', 16, 2000, 1454, 215, 1, N'rear drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (167, N'WAUKD78P89A662503', 12, 1994, 1450, 217, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (168, N'JM3TB2MA6A0887683', 32, 2014, 1675, 223, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (169, N'5TDBK3EH2BS734111', 26, 2019, 1567, 228, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (170, N'WBABV13466J082217', 21, 1993, 1499, 233, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (171, N'WBAPM7C57AE459062', 21, 2007, 1696, 235, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (172, N'2FMPK3K98FB482688', 21, 2007, 1678, 236, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (173, N'WAUKFAFL5EA281418', 69, 2005, 1442, 245, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (174, N'WAUVT68E94A410180', 71, 2009, 1663, 276, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (175, N'2B3CK2CV1AH775495', 71, 2002, 1526, 277, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (176, N'1HGCR2E55EA286661', 71, 1992, 1523, 280, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (177, N'JH4CU2F68BC631071', 71, 1994, 1770, 286, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (178, N'2HNYB1H68DH924015', 73, 1992, 1773, 295, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (179, N'1FTEW1E86AF818093', 72, 1995, 1437, 301, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (180, N'3C6TD4HTXCG839880', 72, 2017, 1488, 302, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (181, N'WVGAV7AX3BW390470', 72, 2011, 1493, 307, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (182, N'WAUUL78E45A200167', 36, 1998, 1532, 310, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (183, N'JTMHY7AJ9B4091499', 13, 2012, 1694, 311, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (184, N'SAJWA0FS8FP468222', 89, 2007, 1614, 340, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (185, N'JM1NC2LF9D0043475', 57, 1999, 1483, 345, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (186, N'1GD422CGXEF170253', 57, 1990, 1579, 370, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (187, N'JN1BV7APXFM590680', 57, 2003, 1762, 371, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (188, N'JHMZF1C46CS958531', 60, 1992, 1572, 373, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (189, N'WAUGGAFR1DA366441', 60, 2005, 1753, 377, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (190, N'WA1WMAFE2DD971257', 64, 1999, 1487, 383, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (191, N'WA1AV94L37D000070', 64, 2016, 1702, 385, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (192, N'WVWAA7AJ5CW398762', 64, 2014, 1587, 301, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (193, N'1G6AP5SX1E0768734', 64, 2001, 1713, 302, 3, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (194, N'WBAWV13557P451979', 77, 1993, 1560, 307, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (195, N'1G6DA1E30E0416888', 77, 2010, 1506, 310, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (196, N'SALFR2BG8FH292196', 15, 2017, 1769, 311, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (197, N'TRUDD38J481844056', 27, 2015, 1567, 340, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (198, N'WDDHH8HB5BA767975', 27, 1997, 1788, 345, 1, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (199, N'WA1CV74LX9D994734', 27, 2019, 1784, 370, 2, N'front-wheel drive')
GO
INSERT [dbo].[Car] ([Id], [VIN], [ModelId], [Year], [Weight], [Color], [EngineType], [TypeOfDrive]) VALUES (200, N'1FTSX2A58AE041570', 68, 1996, 1651, 371, 2, N'front-wheel drive')
GO
SET IDENTITY_INSERT [dbo].[Car] OFF
GO
SET IDENTITY_INSERT [dbo].[CarsManufacturer] ON 
GO
INSERT [dbo].[CarsManufacturer] ([Id], [Name]) VALUES (1, N'BMW')
GO
INSERT [dbo].[CarsManufacturer] ([Id], [Name]) VALUES (2, N'Cadillac')
GO
INSERT [dbo].[CarsManufacturer] ([Id], [Name]) VALUES (3, N'Kia')
GO
INSERT [dbo].[CarsManufacturer] ([Id], [Name]) VALUES (4, N'Volkswagen')
GO
SET IDENTITY_INSERT [dbo].[CarsManufacturer] OFF
GO
SET IDENTITY_INSERT [dbo].[CarsModel] ON 
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (1, N'1-Series', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (2, N'2-Series', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (3, N'3-Series', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (4, N'3-Series GT', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (5, N'3-Series, M3', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (6, N'4-Series, M4', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (7, N'5-Series', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (8, N'5-Series GT', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (9, N'5-Series, M5', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (10, N'6-Series GT', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (11, N'6200', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (12, N'ATS', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (13, N'Allanté', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (14, N'Apollo', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (15, N'Avella', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (16, N'BLS', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (17, N'Bongo', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (18, N'Bongo Frontier', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (19, N'Brasilia', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (20, N'Brougham', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (21, N'CTS', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (22, N'Cadenza / K7', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (23, N'Carens', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (24, N'Carens / Rondo', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (25, N'Carnival / Sedona', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (26, N'Catera', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (27, N'Cee''d', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (28, N'Cerato / Spectra', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (29, N'Cimarron', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (30, N'Clarus', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (31, N'Concord', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (32, N'ELR', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (33, N'Elan', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (34, N'Eldorado', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (35, N'Enterprise', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (36, N'Escalade', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (37, N'Fleetwood', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (38, N'Fleetwood 75', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (39, N'Fleetwood Brougham', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (40, N'Fleetwood Limousine', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (41, N'Forte', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (42, N'Forte / K3', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (43, N'Fox', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (44, N'Fusca', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (45, N'Gol', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (46, N'Joice', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (47, N'Logus', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (48, N'Magentis / Optima', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (49, N'Magentis / Optima / K5', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (50, N'Mohave / Borrego', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (51, N'New Class 1500, 1600, 1800, 2000', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (52, N'New Class 1602, 1802, 2002', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (53, N'New Six CS', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (54, N'Niro', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (55, N'Opirus / Amanti', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (56, N'Parati', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (57, N'Picanto', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (58, N'Pointer', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (59, N'Potentia', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (60, N'Pride', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (61, N'Quantum', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (62, N'Quoris / K9 / K900', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (63, N'Retona', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (64, N'Rio', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (65, N'SP2', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (66, N'Santana', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (67, N'Saveiro', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (68, N'Sephia', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (69, N'Series 60', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (70, N'Series 60 (Sixty Special)', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (71, N'Series 61', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (72, N'Series 62', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (73, N'Series 65', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (74, N'Series 75', 2)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (75, N'Shuma', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (76, N'Sorento', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (77, N'Soul', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (78, N'SpaceFox / Suran / SportVan / Fox Plus', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (79, N'Sportage', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (80, N'Stinger', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (81, N'Stonic', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (82, N'Venga', 3)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (83, N'Voyage', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (84, N'Voyage / Fox', 4)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (85, N'X4', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (86, N'X5', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (87, N'X6', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (88, N'X7', 1)
GO
INSERT [dbo].[CarsModel] ([Id], [Name], [ManufacturerId]) VALUES (89, N'XLR', 2)
GO
SET IDENTITY_INSERT [dbo].[CarsModel] OFF
GO
SET IDENTITY_INSERT [dbo].[Categories] ON 
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (1, N'M')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (2, N'A')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (3, N'A1')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (4, N'B')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (5, N'BE')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (6, N'B1')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (7, N'C')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (8, N'C1')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (9, N'C1E')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (10, N'CE')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (11, N'D')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (12, N'D1')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (13, N'D1E')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (14, N'DE')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (15, N'Tm')
GO
INSERT [dbo].[Categories] ([Id], [Name]) VALUES (16, N'Tb')
GO
SET IDENTITY_INSERT [dbo].[Categories] OFF
GO
SET IDENTITY_INSERT [dbo].[ChangedStatus] ON 
GO
INSERT [dbo].[ChangedStatus] ([Id], [LicenseId], [StatusId], [Comment]) VALUES (1, 204, 3, N'Был в состоянии алкогольного опьянения')
GO
INSERT [dbo].[ChangedStatus] ([Id], [LicenseId], [StatusId], [Comment]) VALUES (2, 205, 3, N'Был в алкогольном опьянении')
GO
INSERT [dbo].[ChangedStatus] ([Id], [LicenseId], [StatusId], [Comment]) VALUES (3, 205, 1, N'Исправился, права восстановлены')
GO
SET IDENTITY_INSERT [dbo].[ChangedStatus] OFF
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (1, 1, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (2, 2, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (3, 3, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (4, 4, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (5, 5, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (6, 6, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (7, 7, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (8, 8, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (9, 9, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (10, 10, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (11, 11, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (12, 12, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (13, 13, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (14, 14, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (15, 15, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (16, 16, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (17, 17, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (18, 18, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (19, 19, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (20, 20, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (21, 21, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (22, 22, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (23, 23, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (24, 24, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (25, 25, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (26, 26, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (27, 27, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (28, 28, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (29, 29, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (30, 30, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (31, 31, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (32, 32, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (33, 33, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (34, 34, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (35, 35, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (36, 36, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (37, 37, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (38, 38, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (39, 39, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (40, 40, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (41, 41, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (42, 42, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (43, 43, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (44, 44, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (45, 45, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (46, 46, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (47, 47, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (48, 48, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (49, 49, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (50, 50, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (51, 51, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (52, 52, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (53, 53, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (54, 54, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (55, 55, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (56, 56, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (57, 57, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (58, 58, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (59, 59, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (60, 60, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (61, 61, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (62, 62, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (63, 63, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (64, 64, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (65, 65, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (66, 66, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (67, 67, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (68, 68, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (69, 69, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (70, 70, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (71, 71, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (72, 72, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (73, 73, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (74, 74, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (75, 75, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (76, 76, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (77, 77, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (78, 78, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (79, 79, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (80, 80, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (81, 81, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (82, 82, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (83, 83, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (84, 84, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (85, 85, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (86, 86, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (87, 87, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (88, 88, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (89, 89, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (90, 90, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (91, 91, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (92, 92, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (93, 93, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (94, 94, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (95, 95, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (96, 96, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (97, 97, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (98, 98, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (99, 99, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (100, 100, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (101, 101, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (102, 102, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (103, 103, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (104, 104, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (105, 105, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (106, 106, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (107, 107, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (108, 108, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (109, 109, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (110, 110, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (111, 111, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (112, 112, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (113, 113, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (114, 114, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (115, 115, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (116, 116, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (117, 117, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (118, 118, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (119, 119, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (120, 120, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (121, 121, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (122, 122, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (123, 123, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (124, 124, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (125, 125, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (126, 126, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (127, 127, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (128, 128, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (129, 129, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (130, 130, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (131, 131, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (132, 132, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (133, 133, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (134, 134, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (135, 135, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (136, 136, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (137, 137, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (138, 138, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (139, 139, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (140, 140, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (141, 141, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (142, 142, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (143, 143, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (144, 144, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (145, 145, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (146, 146, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (147, 147, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (148, 148, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (149, 149, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (150, 150, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (151, 151, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (152, 152, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (153, 153, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (154, 154, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (155, 155, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (156, 156, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (157, 157, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (158, 158, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (159, 159, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (160, 160, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (161, 161, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (162, 162, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (163, 163, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (164, 164, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (165, 165, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (166, 166, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (167, 167, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (168, 168, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (169, 169, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (170, 170, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (171, 171, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (172, 172, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (173, 173, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (174, 174, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (175, 175, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (176, 176, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (177, 177, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (178, 178, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (179, 179, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (180, 180, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (181, 181, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (182, 182, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (183, 183, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (184, 184, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (185, 185, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (186, 186, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (187, 187, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (188, 188, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (189, 189, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (190, 190, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (191, 191, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (192, 192, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (193, 193, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (194, 194, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (195, 195, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (196, 196, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (197, 197, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (198, 198, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (199, 199, NULL)
GO
INSERT [dbo].[DriverOrCar] ([DriverId], [CarId], [Nothing]) VALUES (200, 200, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (1, 1, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (2, 2, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (3, 3, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (4, 4, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (5, 5, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (6, 6, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (7, 7, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (8, 8, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (9, 9, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (10, 10, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (11, 11, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (12, 12, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (13, 13, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (14, 14, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (15, 15, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (16, 16, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (17, 17, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (18, 18, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (19, 19, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (20, 20, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (21, 21, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (22, 22, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (23, 23, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (24, 24, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (25, 25, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (26, 26, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (27, 27, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (28, 28, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (29, 29, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (30, 30, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (31, 31, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (32, 32, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (33, 33, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (34, 34, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (35, 35, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (36, 36, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (37, 37, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (38, 38, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (39, 39, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (40, 40, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (41, 41, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (42, 42, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (43, 43, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (44, 44, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (45, 45, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (46, 46, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (47, 47, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (48, 48, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (49, 49, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (50, 50, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (51, 51, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (52, 52, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (53, 53, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (54, 54, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (55, 55, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (56, 56, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (57, 57, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (58, 58, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (59, 59, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (60, 60, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (61, 61, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (62, 62, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (63, 63, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (64, 64, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (65, 65, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (66, 66, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (67, 67, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (68, 68, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (69, 69, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (70, 70, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (71, 71, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (72, 72, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (73, 73, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (74, 74, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (75, 75, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (76, 76, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (77, 77, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (78, 78, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (79, 79, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (80, 80, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (81, 81, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (82, 82, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (83, 83, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (84, 84, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (85, 85, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (86, 86, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (87, 87, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (88, 88, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (89, 89, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (90, 90, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (91, 91, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (92, 92, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (93, 93, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (94, 94, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (95, 95, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (96, 96, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (97, 97, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (98, 98, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (99, 99, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (100, 100, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (101, 101, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (102, 102, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (103, 103, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (104, 104, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (105, 105, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (106, 106, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (107, 107, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (108, 108, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (109, 109, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (110, 110, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (111, 111, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (112, 112, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (113, 113, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (114, 114, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (115, 115, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (116, 116, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (117, 117, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (118, 118, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (119, 119, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (120, 120, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (121, 121, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (122, 122, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (123, 123, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (124, 124, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (125, 125, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (126, 126, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (127, 127, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (128, 128, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (129, 129, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (130, 130, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (131, 131, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (132, 132, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (133, 133, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (134, 134, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (135, 135, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (136, 136, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (137, 137, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (138, 138, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (139, 139, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (140, 140, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (141, 141, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (142, 142, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (143, 143, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (144, 144, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (145, 145, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (146, 146, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (147, 147, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (148, 148, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (149, 149, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (150, 150, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (151, 151, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (152, 152, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (153, 153, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (154, 154, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (155, 155, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (156, 156, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (157, 157, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (158, 158, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (159, 159, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (160, 160, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (161, 161, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (162, 162, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (163, 163, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (164, 164, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (165, 165, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (166, 166, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (167, 167, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (168, 168, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (169, 169, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (170, 170, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (171, 171, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (172, 172, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (173, 173, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (174, 174, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (175, 175, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (176, 176, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (177, 177, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (178, 178, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (179, 179, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (180, 180, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (181, 181, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (182, 182, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (183, 183, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (184, 184, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (185, 185, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (186, 186, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (187, 187, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (188, 188, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (189, 189, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (190, 190, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (191, 191, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (192, 192, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (193, 193, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (194, 194, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (195, 195, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (196, 196, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (197, 197, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (198, 198, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (199, 199, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (200, 200, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (202, 204, NULL)
GO
INSERT [dbo].[DriverOrLicense] ([DriverId], [LicenseId], [Nothing]) VALUES (203, 205, NULL)
GO
SET IDENTITY_INSERT [dbo].[Drivers] ON 
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (1, N'Hopkins', N'Alonso', N'Caleb', N' 2303 160716', N'Hyattsville  ', N'452 Cobblestone St. ', N'Global Gillette', N'Reporter', N'+7(970)383-8933', N'skippy@icloud.com', N'001-happy-18.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (2, N'Sellers', N'Kaydence', N'Susannah', N' 5563 160745', N'Hanover Park ', N'9648 Philmont Lane ', N'Coca-Cola', N'Elementary School Teacher', N'+7(867)708-4447', N'isotopian@sbcglobal.net', N'002-cool-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (3, N'Bray', N'Finnegan', N'Brighton', N' 3719 717453', N'Woodstock  ', N'8438 North Fairground Court', N'Harley-Davidson Motor Company', N'Childcare worker', N'+7(221)428-7850', N'isaacson@att.net', N'003-happy-17.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (4, N'Arias', N'Gideon', N'Varian', N' 5810 721066', N'Lithonia  ', N'148 Catherine Dr. ', N'Corona', N'Loan Officer', N'+7(786)274-7872', N'mugwump@mac.com', N'004-surprised-9.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (5, N'Schultz', N'Case', N'Aiden', N' 2208 937197', N'Egg Harbor Township', N'7086 th Drive ', N'Johnnie Walker', N'Drafter', N'+7(365)752-6445', N'mcmillan@optonline.net', N'005-shocked-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (6, N'Alvarado', N'Pierre', N'Harriet', N' 7184 275223', N'Villa Park ', N'8992 Union Rd. ', N'SAP', N'Cost Estimator', N'+7(446)639-6043', N'dinther@hotmail.com', N'006-shocked-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (7, N'Bell', N'Esteban', N'Cameron', N' 9563 574791', N'Waynesboro  ', N'12 Windsor St. ', N'Smirnoff', N'Clinical Laboratory Technician', N'+7(555)444-8316', N'pizza@yahoo.com', N'007-nervous-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (8, N'Anderson', N'Spencer', N'Meaghan', N' 9008 379623', N'Garland  ', N'549 Lake View Dr.', N'Toyota Motor Corporation', N'Electrician', N'+7(392)682-4442', N'murty@outlook.com', N'008-nervous-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (9, N'Sweeney', N'Seth', N'Jax', N' 3810 530169', N'Hollywood  ', N'314 N.Gulf Lane ', N'Caterpillar Inc.', N'Referee', N'+7(836)429-0386', N'aegreene@me.com', N'009-angry-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (10, N'Mason', N'Lincoln', N'Emeline', N' 5387 689700', N'Coventry  ', N'3 Cooper Street ', N'Avon', N'Judge', N'+7(283)945-3092', N'jnolan@aol.com', N'010-drool.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (11, N'Curtis', N'Lindsay', N'Syllable', N' 1152 481271', N'Jamaica Plain ', N'53 E.Marvon St. ', N'Budweiser Stag Brewing Company', N'Security Guard', N'+7(621)359-3669', N'msherr@optonline.net', N'011-tired-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (12, N'Daugherty', N'Noah', N'Thomas', N' 2924 764363', N'Canton  ', N'15 Indian Summer St.', N'IBM', N'Budget analyst', N'+7(440)561-0314', N'ranasta@icloud.com', N'012-tongue-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (13, N'Sellers', N'Darien', N'Nadeen', N' 5110 869140', N'Piedmont  ', N'1 Rockville Ave. ', N'Chase', N'Painter', N'+7(331)918-2434', N'punkis@hotmail.com', N'013-tongue-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (14, N'Schneider', N'Jaylene', N'Xavier', N' 6948 84332', N'Savannah  ', N'154 Galvin Ave. ', N'NTT Data', N'Occupational Therapist', N'+7(944)627-0176', N'pereinar@yahoo.com', N'014-tongue-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (15, N'Schmitt', N'Leonard', N'Vincent', N' 7045 366325', N'Lititz  ', N'56 Annadale Dr. ', N'Intel Corporation', N'Physical Therapist', N'+7(621)405-7195', N'tskirvin@mac.com', N'015-smile-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (16, N'Richardson', N'Maya', N'Heath', N' 7100 947091', N'Jackson Heights ', N'7285 Locust Drive ', N'Sony', N'Photographer', N'+7(837)639-1067', N'kewley@sbcglobal.net', N'016-sleeping-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (17, N'Delacruz', N'Thalia', N'Caprice', N' 9169 340517', N'Columbus  ', N'935 West Ave. ', N'Tesco Corporation', N'Cashier', N'+7(769)610-7084', N'ehood@icloud.com', N'017-nervous.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (18, N'Baird', N'Maci', N'Dustin', N' 3097 188032', N'Maryville  ', N'720 Summerhouse Street ', N'Microsoft', N'Educator', N'+7(308)686-7622', N'ilial@aol.com', N'018-surprised-8.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (19, N'Stephenson', N'Ace', N'Amity', N' 7796 170860', N'Irwin  ', N'139 N.Grand St. ', N'McDonald''s', N'Professional athlete', N'+7(319)872-3287', N'elmer@comcast.net', N'019-tongue-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (20, N'Castro', N'Robert', N'Isaiah', N' 5001 550223', N'Evans  ', N'400 Amerige St. ', N'VISA', N'Janitor', N'+7(341)620-5356', N'scarolan@live.com', N'020-happy-16.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (21, N'Stark', N'Efrain', N'Jared', N' 4204 741281', N'Vienna  ', N'225 Iroquois St. ', N'Zara', N'Massage Therapist', N'+7(266)561-7456', N'bwcarty@yahoo.com', N'021-wink-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (22, N'Montgomery', N'Katelynn', N'Drake', N' 1209 731500', N'Long Beach ', N'44 Ocean Ave. ', N'Morgan Stanley', N'Psychologist', N'+7(408)673-0059', N'facet@outlook.com', N'022-laughing-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (23, N'Freeman', N'Sammy', N'Lane', N' 1085 749551', N'Long Branch ', N'192 West Foster St.', N'Mitsubishi', N'IT Manager', N'+7(906)825-5704', N'metzzo@att.net', N'023-laughing-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (24, N'Stokes', N'Jamal', N'Rayleen', N' 7125 277444', N'Centereach  ', N'43 SE.Cross Court ', N'Audi', N'Anthropologist', N'+7(866)732-4338', N'slaff@aol.com', N'024-sweat-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (25, N'Bell', N'Lilliana', N'Quintin', N' 4858 465200', N'Winter Springs ', N'946 Yukon Lane ', N'eBay', N'Executive Assistant', N'+7(744)876-9856', N'caidaperl@mac.com', N'025-happy-15.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (26, N'Ali', N'Jaidyn', N'Kaitlin', N' 9255 131955', N'Titusville  ', N'330 Poplar Lane ', N'Ralph Lauren Corporation', N'Artist', N'+7(872)230-3310', N'jigsaw@verizon.net', N'026-happy-14.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (27, N'Nixon', N'Solomon', N'Jolee', N' 3965 425455', N'Lynn  ', N'626 Leatherwood St. ', N'Wal-Mart', N'Mechanical Engineer', N'+7(572)467-2895', N'hoyer@optonline.net', N'027-laughing.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (28, N'Mcdowell', N'Isaias', N'Kalan', N' 4368 409875', N'Duluth  ', N'9971 N.Rockville Avenue ', N'Panasonic Corporation', N'Firefighter', N'+7(451)768-6075', N'danneng@msn.com', N'028-happy-13.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (29, N'Dean', N'Neveah', N'Evony', N' 9283 299023', N'Phoenixville  ', N'9542 Sutor Drive ', N'Nike, Inc.', N'Carpenter', N'+7(555)802-6671', N'burniske@outlook.com', N'029-happy-12.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (30, N'Waters', N'Koen', N'Abraham', N' 4065 664366', N'Westport  ', N'299 E.George St. ', N'Nissan Motor Co., Ltd.', N'Actuary', N'+7(833)460-5788', N'jipsen@sbcglobal.net', N'030-crying-8.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (31, N'Odom', N'Cale', N'Ann', N' 4877 252066', N'Fair Lawn ', N'7671 Tunnel Street ', N'MTV', N'Compliance Officer', N'+7(234)895-8976', N'agapow@hotmail.com', N'031-crying-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (32, N'Ruiz', N'Layton', N'Aryn', N' 8656 317830', N'Windsor  ', N'41 Harvard Drive ', N'Cartier SA', N'Computer Systems Administrator', N'+7(682)469-8567', N'mobileip@icloud.com', N'032-bored.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (33, N'Patrick', N'Monserrat', N'Coralie', N' 1583 513755', N'Rolla  ', N'7219 Prospect Drive ', N'Nescafé', N'HR Specialist', N'+7(682)555-7940', N'mglee@yahoo.com', N'033-cool-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (34, N'Hardin', N'Kamden', N'Ray', N' 2179 517256', N'Arlington Heights ', N'697 Cypress Lane ', N'Allianz', N'Recreation & Fitness Worker', N'+7(575)985-7625', N'animats@yahoo.ca', N'034-angry-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (35, N'Neal', N'Janiya', N'Irene', N' 5244 495362', N'Holly Springs ', N'7762 North County St.', N'Ferrari S.p.A.', N'Financial Advisor', N'+7(313)507-8540', N'drewf@me.com', N'035-sad-14.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (36, N'Winters', N'Cornelius', N'James', N' 9584 586486', N'New Haven ', N'7773 Ridge Dr. ', N'Kleenex', N'Auto Mechanic', N'+7(608)783-0267', N'slanglois@msn.com', N'036-angry-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (37, N'Love', N'Kaden', N'Neil', N' 1850 453434', N'Mount Holly ', N'551 Spruce St. ', N'Tiffany & Co.', N'Web Developer', N'+7(688)656-7203', N'notaprguy@verizon.net', N'037-happy-11.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (38, N'Mills', N'Finley', N'Ace', N' 4286 976952', N'Bridgewater  ', N'116 Woodside St. ', N'3M', N'Civil Engineer', N'+7(530)402-7915', N'yruan@sbcglobal.net', N'038-angry-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (39, N'Henry', N'Markus', N'Edward', N' 2767 784535', N'West Des Moines', N'9817 Manor St. ', N'Shell Oil Company', N'Chemist', N'+7(262)635-2834', N'bmorrow@me.com', N'039-cyclops-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (40, N'Singleton', N'Romeo', N'Preston', N' 7677 990002', N'Brookline  ', N'0875 rince Street ', N'Adobe Systems', N'Recreational Therapist', N'+7(487)957-3536', N'adillon@verizon.net', N'040-surprised-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (41, N'Glenn', N'Ethen', N'Kate', N' 6342 37367', N'Dundalk  ', N'549 Marvon St. ', N'IKEA', N'Microbiologist', N'+7(918)285-4740', N'kimvette@me.com', N'041-thinking-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (42, N'Gordon', N'Abbey', N'Berlynn', N' 8909 475995', N'Lumberton  ', N'1 Theatre Drive ', N'Nokia', N'Event Planner', N'+7(412)706-8937', N'emcleod@outlook.com', N'042-book.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (43, N'Vasquez', N'Presley', N'Sheridan', N' 9144 720543', N'Farmingdale  ', N'673 Hamilton Road ', N'Sprite', N'Coach', N'+7(454)353-8089', N'stomv@aol.com', N'043-baby-boy.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (44, N'Levine', N'Alexis', N'Juan', N' 6021 143882', N'Hamburg  ', N'9662 Bay Ave. ', N'Xerox', N'Radiologic Technologist', N'+7(623)716-7237', N'msusa@comcast.net', N'044-dead-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (45, N'Miles', N'Steve', N'Lydon', N' 4607 499410', N'Wisconsin Rapids ', N'8604 Fairfield Ave. ', N'Samsung Group', N'Market Research Analyst', N'+7(594)615-8545', N'dougj@yahoo.com', N'045-star.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (46, N'Cuevas', N'Kayley', N'Tyson', N' 4676 263545', N'Mount Juliet ', N'56 Vale St. ', N'Google', N'Housekeeper', N'+7(647)885-2301', N'jlbaumga@gmail.com', N'046-dubious.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (47, N'Hebert', N'Annabelle', N'Annora', N' 6571 27113', N'Tullahoma  ', N'9523 Linda Lane ', N'Louis Vuitton', N'Computer Programmer', N'+7(822)693-3953', N'temmink@mac.com', N'047-phone-call.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (48, N'Casey', N'Carolina', N'Timothy', N' 2307 511412', N'Ann Arbor ', N'3 Ashley Ave. ', N'Apple Inc.', N'Secretary', N'+7(887)236-8493', N'nighthawk@msn.com', N'048-moon.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (49, N'Roach', N'Beckham', N'Elias', N' 4756 956293', N'Dothan  ', N'9851 East Prince Street', N'Verizon Communications', N'Bus Driver', N'+7(531)597-0196', N'qmacro@outlook.com', N'049-robot.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (50, N'Pugh', N'Seamus', N'Jackson', N' 4693 133588', N'Hartford  ', N'8329 North Greenview St.', N'Credit Suisse', N'Systems Analyst', N'+7(506)774-1574', N'stewwy@att.net', N'050-flower.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (51, N'Calderon', N'Imani', N'Sullivan', N' 7598 90859', N'Annapolis  ', N'215 Purple Finch Lane', N'Wells Fargo', N'Chef', N'+7(639)813-8035', N'blixem@msn.com', N'051-happy-10.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (52, N'Roach', N'Marisol', N'Dezi', N' 2416 240325', N'Hagerstown  ', N'635 3rd Ave. ', N'Yahoo!', N'Registered Nurse', N'+7(883)455-5204', N'mccurley@optonline.net', N'052-happy-9.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (53, N'Jacobson', N'Kane', N'Emerson', N' 3896 957754', N'Maspeth  ', N'2 Greenrose Rd. ', N'Porsche', N'Surveyor', N'+7(833)914-4764', N'jacks@mac.com', N'053-tired-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (54, N'Higgins', N'Anya', N'Erin', N' 6573 581276', N'Howell  ', N'298 N.Hudson Court ', N'Moët et Chandon', N'Urban Planner', N'+7(810)945-3933', N'nwiger@att.net', N'054-ugly-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (55, N'Richard', N'Branson', N'Linnea', N' 2225 886655', N'Bayonne  ', N'0625 eg Shop St.', N'Hyundai', N'Middle School Teacher', N'+7(995)610-9002', N'muadip@me.com', N'055-tongue-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (56, N'Mathis', N'Kyle', N'Raine', N' 8966 340666', N'South Richmond Hill', N'648 Hill Field St.', N'Honda Motor Company, Ltd', N'Speech-Language Pathologist', N'+7(394)581-3937', N'gavinls@yahoo.com', N'056-vampire.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (57, N'Cross', N'Jamiya', N'Trevor', N' 1754 958143', N'Lynnwood  ', N'477 Oakland Street ', N'Beko', N'Personal Care Aide', N'+7(732)375-2363', N'nicktrig@me.com', N'057-music-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (58, N'Keller', N'Selah', N'Merle', N' 4434 406702', N'Champlin  ', N'4 Division Lane ', N'Deere & Company', N'Database administrator', N'+7(587)444-2070', N'lbecchi@me.com', N'058-popcorn.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (59, N'Watson', N'Larry', N'Blayne', N' 4859 211563', N'Lancaster  ', N'8021 Shadow Brook Dr.', N'Volkswagen Group', N'Art Director', N'+7(845)438-1802', N'willg@att.net', N'059-nurse.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (60, N'Shea', N'Braeden', N'Abe', N' 5348 104186', N'West Babylon ', N'7073 Hall Avenue ', N'Pampers', N'Landscaper & Groundskeeper', N'+7(320)478-3865', N'rnelson@yahoo.com', N'060-sad-13.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (61, N'Woodard', N'Allisson', N'Joan', N' 9216 132859', N'South Windsor ', N'985 BWinding Way Dr.', N'BlackBerry', N'Court Reporter', N'+7(486)828-8733', N'roesch@aol.com', N'061-graduated-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (62, N'Garner', N'Amy', N'Tanner', N' 6127 199319', N'Billerica  ', N'570 Old Bayberry Street', N'Jack Daniel''s', N'Bookkeeping clerk', N'+7(497)215-8724', N'pthomsen@verizon.net', N'062-happy-8.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (63, N'Choi', N'Saniyah', N'Debree', N' 1102 719495', N'East Lansing ', N'9122 South Addison St.', N'Facebook, Inc.', N'Landscape Architect', N'+7(399)887-3591', N'itstatus@yahoo.ca', N'063-hungry.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (64, N'Simmons', N'Reagan', N'Sharon', N' 2020 814747', N'Skokie  ', N'14 West Fifth St.', N'United Parcel Service', N'College Professor', N'+7(205)278-4756', N'marcs@verizon.net', N'064-police.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (65, N'Robertson', N'Coby', N'Juliet', N' 4083 683928', N'Harrisonburg  ', N'7267 W.Roehampton St. ', N'Adidas', N'Respiratory Therapist', N'+7(260)814-7458', N'tellis@yahoo.ca', N'065-crying-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (66, N'Haney', N'Dakota', N'Marguerite', N' 1270 718764', N'Cambridge  ', N'82 Oak Meadow Dr.', N'Siemens AG', N'Mason', N'+7(302)844-3480', N'scotfl@att.net', N'066-happy-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (67, N'Rivas', N'Malia', N'Louis', N' 3871 532007', N'Alliance  ', N'864 Highland Drive ', N'Citigroup', N'Veterinarian', N'+7(449)380-7477', N'jramio@optonline.net', N'067-sun.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (68, N'Green', N'Lily', N'Lynn', N' 9827 633690', N'Massillon  ', N'9465 St Paul Avenue', N'Amazon.com', N'Architect', N'+7(280)214-8022', N'mastinfo@gmail.com', N'068-father-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (69, N'Nielsen', N'Reilly', N'Marcella', N' 9350 821275', N'Centreville  ', N'7651 South La Sierra', N'AT&T', N'Accountant', N'+7(967)763-6475', N'ateniese@outlook.com', N'069-happy-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (70, N'Brooks', N'Ryleigh', N'Leonie', N' 2681 769203', N'Glen Allen ', N'3 Alton Lane ', N'Starbucks', N'School Counselor', N'+7(625)810-5235', N'ismail@hotmail.com', N'070-late.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (71, N'Ewing', N'Brendan', N'Adele', N' 4152 160995', N'Florence  ', N'9441 W.Pineknoll Drive ', N'Prada', N'Computer Support Specialist', N'+7(975)483-5566', N'oechslin@optonline.net', N'071-heart.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (72, N'Kirk', N'Cheyenne', N'Julian', N' 4306 595389', N'Lewiston  ', N'7070 Shady Street ', N'Gap Inc.', N'Historian', N'+7(718)850-2518', N'jugalator@att.net', N'072-sick-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (73, N'Rojas', N'Jacoby', N'Rose', N' 9367 402446', N'Billings  ', N'146 East Bank Street', N'Kia Motors', N'Computer Hardware Engineer', N'+7(550)645-2520', N'subir@verizon.net', N'073-sad-12.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (74, N'Cummings', N'Keshawn', N'Paul', N' 4536 115339', N'Norman  ', N'8723 Cedar Swamp Drive', N'Cisco Systems, Inc.', N'Designer', N'+7(551)270-4620', N'bryam@verizon.net', N'074-in-love-10.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (75, N'Crawford', N'Mohammed', N'Amelia', N' 8478 213639', N'Groton  ', N'8419 E.Harvey Drive ', N'Home Depot', N'Hairdresser', N'+7(489)444-3438', N'jpflip@optonline.net', N'075-shocked-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (76, N'Bryan', N'Nancy', N'Devon', N' 1871 347268', N'Chelmsford  ', N'179 Manchester St. ', N'Vodafone', N'Lawyer', N'+7(401)862-1637', N'mgemmons@comcast.net', N'076-happy-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (77, N'Lynn', N'Maxwell', N'Ellory', N' 1567 431190', N'Durham  ', N'70 Cambridge Ave. ', N'Hewlett-Packard', N'Real Estate Agent', N'+7(507)625-4900', N'csilvers@icloud.com', N'077-shocked-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (78, N'Khan', N'Zack', N'Gabriel', N' 9952 372202', N'Forney  ', N'566 S.Cherry Street ', N'Hermès', N'Customer Service Representative', N'+7(458)566-0054', N'karasik@msn.com', N'078-cool-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (79, N'Walls', N'Selina', N'Ashten', N' 8168 514525', N'Norwood  ', N'83 NE.Hill Dr. ', N'Oracle Corporation', N'Fitness Trainer', N'+7(979)346-6593', N'wetter@yahoo.ca', N'079-crying-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (80, N'Garner', N'Jerry', N'Everett', N' 8239 393741', N'Nottingham  ', N'556 Summerhouse Street ', N'Canon', N'Social Worker', N'+7(320)547-9952', N'thassine@me.com', N'080-zombie.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (81, N'Carroll', N'Kaila', N'Grey', N' 2909 822374', N'Muskogee  ', N'9750 Hawthorne Ave. ', N'KFC', N'Economist', N'+7(429)809-1931', N'sassen@msn.com', N'081-pain.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (82, N'Conway', N'Sean', N'Garrison', N' 5367 598823', N'Seymour  ', N'97 Elmwood Street ', N'General Electric', N'Writer', N'+7(464)285-9954', N'jandrese@yahoo.ca', N'082-cyclops.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (83, N'Cantu', N'Makaila', N'Fernando', N' 5298 472573', N'Algonquin  ', N'308 Studebaker Drive ', N'BMW', N'Logistician', N'+7(748)461-4491', N'tmccarth@live.com', N'083-sweat.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (84, N'Mccall', N'Jacquelyn', N'Sherleen', N' 3605 373737', N'Garden City ', N'15 Marsh St. ', N'The Walt Disney Company', N'Environmental scientist', N'+7(578)935-1637', N'gtewari@icloud.com', N'084-thief.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (85, N'Swanson', N'Milton', N'Chase', N' 8146 691253', N'Wake Forest ', N'8614 Charles Street ', N'American Express', N'Patrol Officer', N'+7(927)652-4631', N'hampton@yahoo.com', N'085-sad-11.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (86, N'Lynn', N'Rodolfo', N'Zion', N' 7932 623470', N'South Lyon ', N'57 Gulf Avenue ', N'Burberry', N'Plumber', N'+7(595)615-6057', N'jesse@me.com', N'086-kiss-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (87, N'Walls', N'Paula', N'Breean', N' 7817 774559', N'Missoula  ', N'694 Linden St. ', N'Pizza Hut', N'Dancer', N'+7(751)240-3137', N'jugalator@me.com', N'087-father-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (88, N'Olson', N'Adison', N'Henry', N' 4402 114286', N'Zeeland  ', N'8440 Lyme St. ', N'H&M', N'Pharmacist', N'+7(626)974-2035', N'bhima@sbcglobal.net', N'088-father.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (89, N'Haynes', N'Jacob', N'Marcellus', N' 2794 857949', N'Pembroke Pines ', N'7632 Oakwood Rd. ', N'Heineken Brewery', N'Truck Driver', N'+7(201)979-1451', N'gommix@comcast.net', N'089-angel-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (90, N'Roberts', N'Corinne', N'Suzan', N' 7429 823005', N'South El Monte', N'881 Temple St. ', N'PepsiCo', N'Medical Secretary', N'+7(493)219-3942', N'symbolic@verizon.net', N'090-happy-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (91, N'Ewing', N'Aimee', N'Lane', N' 6306 285690', N'Webster  ', N'9591 Honey Creek St.', N'Bank of America', N'Diagnostic Medical Sonographer', N'+7(407)485-5030', N'bruck@outlook.com', N'091-sad-10.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (92, N'Cordova', N'Alejandro', N'Hollyn', N' 9370 315564', N'Bismarck  ', N'7018 Pilgrim Street ', N'Nintendo', N'High School Teacher', N'+7(919)478-2497', N'jeteve@optonline.net', N'092-outrage-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (93, N'Haynes', N'Byron', N'Bram', N' 1685 42988', N'Harleysville  ', N'697 Westminster St. ', N'Johnson & Johnson', N'Marriage & Family Therapist', N'+7(482)802-9580', N'jsnover@comcast.net', N'093-ugly-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (94, N'Keith', N'Genevieve', N'David', N' 5467 865823', N'Euless  ', N'959 Birchpond St. ', N'HSBC', N'Editor', N'+7(455)944-6449', N'hakim@comcast.net', N'094-ugly-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (95, N'Obrien', N'Dane', N'Shane', N' 9596 712362', N'Yorktown Heights ', N'67 Pumpkin Hill Lane', N'Kellogg Company', N'Substance Abuse Counselor', N'+7(710)388-2563', N'dexter@sbcglobal.net', N'095-scared.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (96, N'Church', N'Nayeli', N'Kent', N' 9527 410913', N'Ithaca  ', N'5 NE.Newcastle Drive ', N'MasterCard', N'Public Relations Specialist', N'+7(759)452-3846', N'jlbaumga@hotmail.com', N'096-tongue-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (97, N'Jimenez', N'Ashtyn', N'Rhett', N' 6760 404116', N'Mount Prospect ', N'94 Longbranch St. ', N'Gucci', N'Computer Systems Analyst', N'+7(687)801-1332', N'djupedal@hotmail.com', N'097-sad-9.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (98, N'Wilkerson', N'Kimberly', N'Carelyn', N' 9484 965470', N'Wantagh  ', N'566 Gulf St. ', N'Mercedes-Benz', N'Preschool Teacher', N'+7(691)336-3494', N'daveewart@verizon.net', N'098-nerd-9.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (99, N'Curtis', N'Tripp', N'Apollo', N' 6426 682782', N'Encino  ', N'518 Clinton Ave. ', N'L''Oréal', N'Dentist', N'+7(493)274-3888', N'msherr@sbcglobal.net', N'099-greed-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (100, N'Zavala', N'Eleanor', N'George', N' 3709 656706', N'Wausau  ', N'370 Ashley Lane ', N'Global Gillette', N'Teacher Assistant', N'+7(983)470-4528', N'crusader@sbcglobal.net', N'100-whistle.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (101, N'Thomas', N'Harper', N'Jae', N' 4948 205524', N'Menasha  ', N'477 Southampton Avenue ', N'Coca-Cola', N'Musician', N'+7(436)951-8996', N'mdielmann@sbcglobal.net', N'101-nerd-8.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (102, N'Stephenson', N'Maximo', N'Dex', N' 8134 605243', N'Hoboken  ', N'9668 Glendale Court ', N'Harley-Davidson Motor Company', N'Paralegal', N'+7(210)889-7840', N'ovprit@me.com', N'102-muted-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (103, N'James', N'Kiara', N'Jeremy', N' 7133 997003', N'Basking Ridge ', N'7175 Sherwood Street ', N'Corona', N'Software Developer', N'+7(390)499-7403', N'calin@att.net', N'103-in-love-9.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (104, N'Fuller', N'Isabella', N'Naomi', N' 4021 304017', N'Joliet  ', N'9549 Lake Ave. ', N'Johnnie Walker', N'Zoologist', N'+7(805)721-8540', N'thowell@yahoo.ca', N'104-in-love-8.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (105, N'Garrison', N'Cynthia', N'Matilda', N' 3516 398883', N'San Lorenzo ', N'7756 Philmont Dr. ', N'SAP', N'Medical Assistant', N'+7(578)220-5882', N'mpiotr@yahoo.com', N'105-kiss-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (106, N'Flowers', N'Donte', N'Brock', N' 8533 684076', N'Owatonna  ', N'66 Buttonwood Ave. ', N'Smirnoff', N'Desktop publisher', N'+7(415)631-8358', N'bester@gmail.com', N'106-in-love-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (107, N'Rivera', N'Asia', N'Carmden', N' 1618 439727', N'Severn  ', N'372 West Cedarwood Drive', N'Toyota Motor Corporation', N'Actor', N'+7(900)903-0657', N'imightb@gmail.com', N'107-ugly.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (108, N'Hahn', N'Trace', N'Clelia', N' 2835 991998', N'Bolingbrook  ', N'368 W.Gregory Drive ', N'Caterpillar Inc.', N'Sports Coach', N'+7(879)442-6528', N'jschauma@icloud.com', N'108-nerd-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (109, N'Farley', N'Mohammed', N'Levi', N' 7748 504230', N'Montgomery  ', N'553 Tallwood Rd. ', N'Avon', N'Dental Hygienist', N'+7(649)374-4690', N'syrinx@gmail.com', N'109-nerd-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (110, N'Velez', N'Nicholas', N'Dawn', N' 4853 175687', N'Doylestown  ', N'769 Old Atlantic Rd.', N'Budweiser Stag Brewing Company', N'School Psychologist', N'+7(487)871-5975', N'konit@aol.com', N'110-crying-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (111, N'Curtis', N'Jamir', N'Tavian', N' 3983 947212', N'Osseo  ', N'71 Carson Ave. ', N'IBM', N'Librarian', N'+7(503)572-6773', N'wonderkid@hotmail.com', N'111-muted-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (112, N'Rose', N'Cyrus', N'Jacklyn', N' 7435 360206', N'Port Orange ', N'8389 Eagle Lane ', N'Chase', N'Telemarketer', N'+7(709)756-6389', N'pjacklam@verizon.net', N'112-nerd-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (113, N'Torres', N'Dakota', N'Cash', N' 4559 179023', N'Eastpointe  ', N'757 Goldfield St. ', N'NTT Data', N'Interpreter & Translator', N'+7(931)652-7478', N'tokuhirom@live.com', N'113-kiss-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (114, N'Valencia', N'Matias', N'Reagan', N' 2102 137023', N'Scotch Plains ', N'28 Lakewood Drive ', N'Intel Corporation', N'Food Scientist', N'+7(524)449-7554', N'adillon@comcast.net', N'114-greed-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (115, N'Harding', N'Rocco', N'Gwendolen', N' 2018 304278', N'Kaukauna  ', N'11 Belmont St. ', N'Sony', N'Marketing Manager', N'+7(347)807-8932', N'bcevc@yahoo.ca', N'115-pirate-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (116, N'Clark', N'Maya', N'Evelyn', N' 4625 441301', N'El Paso ', N'59 North Brandywine Street', N'Tesco Corporation', N'Insurance Agent', N'+7(675)694-8839', N'crobles@me.com', N'116-music.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (117, N'Hays', N'Bryan', N'Wade', N' 8451 370682', N'Oshkosh  ', N'752 Highland Street ', N'Microsoft', N'Farmer', N'+7(779)966-8126', N'tjensen@verizon.net', N'117-confused-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (118, N'Nelson', N'Jessie', N'Jack', N' 7035 527026', N'Palos Verdes Peninsula', N'258 Talbot Drive ', N'McDonald''s', N'Human Resources Assistant', N'+7(791)357-4942', N'gozer@icloud.com', N'118-nerd-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (119, N'Franklin', N'Joy', N'Warren', N' 2846 798890', N'Redondo Beach ', N'407 Mechanic Street ', N'VISA', N'Paramedic', N'+7(292)662-7836', N'brbarret@yahoo.ca', N'119-greed.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (120, N'Lang', N'Carlie', N'Rebecca', N' 9368 90494', N'Northville  ', N'729 Cypress Court ', N'Zara', N'Automotive mechanic', N'+7(952)374-4396', N'mcnihil@me.com', N'120-nerd-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (121, N'Hurley', N'Issac', N'Blanche', N' 7906 721186', N'Charlotte  ', N'975 Rockledge Street ', N'Morgan Stanley', N'Receptionist', N'+7(758)849-9991', N'damian@yahoo.com', N'121-crying-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (122, N'Sims', N'Ariel', N'Bailey', N' 9254 479522', N'Miami Beach ', N'953 Bishop St. ', N'Mitsubishi', N'Construction Manager', N'+7(534)687-2128', N'neonatus@aol.com', N'122-cheering.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (123, N'Delgado', N'Braedon', N'Oliver', N' 3627 384983', N'Chicopee  ', N'13 Magnolia Ave. ', N'Audi', N'Physician', N'+7(642)548-4829', N'tellis@icloud.com', N'123-surprised-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (124, N'Suarez', N'Christian', N'Lee', N' 5989 222522', N'Windermere  ', N'7569 Ocean Street ', N'eBay', N'Mathematician', N'+7(980)531-5346', N'frode@live.com', N'124-muted-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (125, N'Marks', N'Lilah', N'Anthony', N' 3584 358162', N'Stuart  ', N'8897 Cross St. ', N'Ralph Lauren Corporation', N'Electrical Engineer', N'+7(628)326-1104', N'sjava@aol.com', N'125-sick-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (126, N'Rowland', N'Jeffrey', N'Gillian', N' 4406 46042', N'Rome  ', N'5 Dogwood Street ', N'Wal-Mart', N'Physicist', N'+7(669)335-7511', N'harryh@live.com', N'126-graduated.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (127, N'Jordan', N'Hannah', N'Verena', N' 5511 931653', N'Owings Mills ', N'65 West8  ', N'Panasonic Corporation', N'Police Officer', N'+7(399)344-8840', N'elflord@me.com', N'127-angry-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (128, N'Hinton', N'Peyton', N'Benjamin', N' 8020 284910', N'Spring Hill ', N'8245 Shub Farm Ave.', N'Nike, Inc.', N'Maintenance & Repair Worker', N'+7(643)676-5328', N'ramollin@mac.com', N'128-in-love-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (129, N'Forbes', N'Clayton', N'Zachary', N' 8660 236405', N'Lorton  ', N'7126 Pheasant St. ', N'Nissan Motor Co., Ltd.', N'Statistician', N'+7(535)983-7587', N'kronvold@mac.com', N'129-cool-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (130, N'Cabrera', N'Salvatore', N'Krystan', N' 7218 277801', N'Thomasville  ', N'7609 Gates St. ', N'MTV', N'Epidemiologist', N'+7(310)925-8844', N'louise@aol.com', N'130-confused-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (131, N'Taylor', N'Andre', N'Felix', N' 4813 710684', N'Oak Park ', N'935 Glen Ridge Ave.', N'Cartier SA', N'Reporter', N'+7(457)847-6033', N'nanop@verizon.net', N'131-sad-8.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (132, N'Mcclain', N'Kadin', N'Riley', N' 8704 683064', N'Griffin  ', N'7795 Greenrose St. ', N'Nescafé', N'Elementary School Teacher', N'+7(330)730-7648', N'gtewari@sbcglobal.net', N'132-nerd-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (133, N'Nichols', N'Jaida', N'Lucinda', N' 9908 341967', N'Suwanee  ', N'403 W.College St. ', N'Allianz', N'Childcare worker', N'+7(619)883-4911', N'ylchang@mac.com', N'133-birthday-boy.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (134, N'Church', N'Reid', N'Candice', N' 6752 159699', N'Merrillville  ', N'716 Chestnut Avenue ', N'Ferrari S.p.A.', N'Loan Officer', N'+7(482)744-7133', N'gommix@yahoo.com', N'134-surprised-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (135, N'Harrington', N'Karley', N'Kathryn', N' 8059 911426', N'Nashville  ', N'9024 Nicolls Ave. ', N'Kleenex', N'Drafter', N'+7(369)537-4704', N'uncle@sbcglobal.net', N'135-selfie.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (136, N'Rivers', N'Beau', N'Lillian', N' 8452 55461', N'Glendale  ', N'33 Foxrun St. ', N'Tiffany & Co.', N'Cost Estimator', N'+7(540)239-8104', N'smcnabb@live.com', N'136-tongue-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (137, N'Bentley', N'Riley', N'Hugh', N' 4452 331700', N'Oak Creek ', N'8012 North Wild Horse', N'3M', N'Clinical Laboratory Technician', N'+7(863)714-2111', N'shrapnull@aol.com', N'137-smart-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (138, N'Choi', N'Ellis', N'Julina', N' 3520 765331', N'Bemidji  ', N'759 Crescent Dr. ', N'Shell Oil Company', N'Electrician', N'+7(839)694-4168', N'djpig@sbcglobal.net', N'138-smart.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (139, N'Leon', N'Jaylyn', N'Ellison', N' 8629 761047', N'Brooklyn  ', N'518 Overlook Street ', N'Adobe Systems', N'Referee', N'+7(983)868-6473', N'oechslin@hotmail.com', N'139-surprised-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (140, N'Mayer', N'Drew', N'Carlen', N' 2381 911641', N'Des Plaines ', N'7660 Armstrong Drive ', N'IKEA', N'Judge', N'+7(325)574-7514', N'xnormal@verizon.net', N'140-3d-glasses.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (141, N'Walters', N'Ashleigh', N'Claude', N' 3634 590673', N'Mansfield  ', N'5 Miles Street ', N'Nokia', N'Security Guard', N'+7(921)683-0258', N'atmarks@icloud.com', N'141-in-love-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (142, N'Dickerson', N'Scott', N'Arden', N' 5913 725569', N'Deer Park ', N'48 N.Valley View Drive', N'Sprite', N'Budget analyst', N'+7(503)446-7180', N'makarow@comcast.net', N'142-sleeping.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (143, N'Knight', N'Kolton', N'Miriam', N' 7702 344201', N'Suitland  ', N'8057 Annadale Ave. ', N'Xerox', N'Painter', N'+7(467)243-5219', N'raides@yahoo.com', N'143-pirate.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (144, N'Boyle', N'Izabelle', N'Naveen', N' 2262 625946', N'Cedar Rapids ', N'354 Blackburn Dr. ', N'Samsung Group', N'Occupational Therapist', N'+7(633)700-7724', N'hwestiii@mac.com', N'144-santa-claus.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (145, N'Singleton', N'Haylie', N'Sue', N' 1646 243340', N'Cary  ', N'86 Paris Hill St.', N'Google', N'Physical Therapist', N'+7(632)874-7209', N'scitext@gmail.com', N'145-wink.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (146, N'Lin', N'Sariah', N'Olive', N' 2153 460491', N'Austin  ', N'7573 Bridgeton Street ', N'Louis Vuitton', N'Photographer', N'+7(368)599-1877', N'gward@yahoo.ca', N'146-in-love-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (147, N'Spears', N'Chace', N'Elodie', N' 3126 716773', N'Beckley  ', N'579 E.Evergreen St. ', N'Apple Inc.', N'Cashier', N'+7(324)886-1499', N'bockelboy@outlook.com', N'147-tired.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (148, N'Frazier', N'Liam', N'Korin', N' 8828 972758', N'Floral Park ', N'805 Magnolia St. ', N'Verizon Communications', N'Educator', N'+7(374)356-4166', N'tubesteak@comcast.net', N'148-bang.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (149, N'Stokes', N'Joseph', N'William', N' 8114 880420', N'Hyde Park ', N'6 Euclid St. ', N'Credit Suisse', N'Professional athlete', N'+7(868)982-2419', N'krueger@mac.com', N'149-baby.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (150, N'Hurley', N'Lorelei', N'Coralie', N' 8085 811955', N'Huntington Station ', N'9381 Pilgrim Lane ', N'Wells Fargo', N'Janitor', N'+7(781)785-5837', N'skaufman@optonline.net', N'150-tongue.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (151, N'Leon', N'Miguel', N'Haiden', N' 1318 208906', N'Marion  ', N'200 Warren Court ', N'Yahoo!', N'Massage Therapist', N'+7(489)361-6374', N'tezbo@live.com', N'151-sick-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (152, N'Hamilton', N'Melina', N'Isaac', N' 3115 642377', N'North Royalton ', N'8558 Summerhouse St. ', N'Porsche', N'Psychologist', N'+7(872)856-7001', N'crowl@icloud.com', N'152-outrage.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (153, N'Duke', N'Serena', N'Arthur', N' 5150 553212', N'Mankato  ', N'977 Longbranch Drive ', N'Moët et Chandon', N'IT Manager', N'+7(812)814-4854', N'plover@hotmail.com', N'153-injury.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (154, N'Dillon', N'Kristen', N'Kylie', N' 4169 626192', N'Sumter  ', N'9600 Ketch Harbour Ave.', N'Hyundai', N'Anthropologist', N'+7(803)510-4214', N'calin@aol.com', N'154-dead.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (155, N'Hawkins', N'Saniyah', N'Josiah', N' 7466 33192', N'Wilmington  ', N'959 Elmwood St. ', N'Honda Motor Company, Ltd', N'Executive Assistant', N'+7(869)369-9524', N'timtroyr@live.com', N'155-rich-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (156, N'Leach', N'Thalia', N'Nicolas', N' 2646 768816', N'Saint Louis ', N'8269 Buckingham St. ', N'Beko', N'Artist', N'+7(464)585-3155', N'keutzer@yahoo.com', N'156-sick.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (157, N'Caldwell', N'Irene', N'Noah', N' 5732 336554', N'Manchester  ', N'8990 Columbia Street ', N'Deere & Company', N'Mechanical Engineer', N'+7(703)958-7186', N'thurston@outlook.com', N'157-angel.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (158, N'Bowen', N'Nikhil', N'Glenn', N' 5254 555116', N'Chester  ', N'292 Virginia Street ', N'Volkswagen Group', N'Firefighter', N'+7(515)615-0912', N'mbalazin@att.net', N'158-nerd-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (159, N'Charles', N'Jolie', N'Matteo', N' 3285 403999', N'Westmont  ', N'24810 th Dr. ', N'Pampers', N'Carpenter', N'+7(854)941-5210', N'dkasak@gmail.com', N'159-crying-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (160, N'Baxter', N'Xavier', N'Joseph', N' 1373 588622', N'Loveland  ', N'199 East Chestnut Dr.', N'BlackBerry', N'Actuary', N'+7(380)573-4186', N'esbeck@comcast.net', N'160-crying-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (161, N'Dean', N'Lukas', N'Ellice', N' 1890 691040', N'Banning  ', N'83 Carriage Street ', N'Jack Daniel''s', N'Compliance Officer', N'+7(297)369-0265', N'novanet@aol.com', N'161-muted-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (162, N'King', N'Athena', N'Lilibeth', N' 3307 217825', N'Bethpage  ', N'9971 Smith Store Ave.', N'Facebook, Inc.', N'Computer Systems Administrator', N'+7(671)293-5634', N'mhouston@me.com', N'162-surprised-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (163, N'Noble', N'Adan', N'Bree', N' 3286 297169', N'Fenton  ', N'708 East Oak Valley', N'United Parcel Service', N'HR Specialist', N'+7(305)214-6934', N'bahwi@yahoo.com', N'163-crying.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (164, N'Pham', N'Kiley', N'Madeleine', N' 2401 289619', N'Atlantic City ', N'17 Broad Dr. ', N'Adidas', N'Recreation & Fitness Worker', N'+7(812)919-9643', N'chrisj@outlook.com', N'164-sad-7.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (165, N'Johnston', N'Steven', N'Kai', N' 8507 252786', N'Huntley  ', N'765 Devonshire Dr. ', N'Siemens AG', N'Financial Advisor', N'+7(754)769-3349', N'louise@gmail.com', N'165-cool-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (166, N'Hart', N'Ayana', N'Dash', N' 9342 187671', N'Vista  ', N'9027 Fairway Drive ', N'Citigroup', N'Auto Mechanic', N'+7(206)323-2722', N'qrczak@me.com', N'166-happy-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (167, N'Copeland', N'Aileen', N'Seth', N' 1067 401389', N'Harlingen  ', N'20 Indian Spring St.', N'Amazon.com', N'Web Developer', N'+7(273)495-7160', N'arachne@hotmail.com', N'167-thinking-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (168, N'Pitts', N'Emery', N'Eli', N' 2273 445653', N'Pompano Beach ', N'9267 South Glenholme Ave.', N'AT&T', N'Civil Engineer', N'+7(463)932-3808', N'mfburgo@icloud.com', N'168-muted.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (169, N'Chavez', N'Vicente', N'Bernice', N' 6403 754163', N'Auburn  ', N'65 South Pineknoll Ave.', N'Starbucks', N'Chemist', N'+7(551)789-0645', N'karasik@att.net', N'169-confused.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (170, N'Monroe', N'Cherish', N'Vanessa', N' 3912 930948', N'Greenfield  ', N'160 Inverness St. ', N'Prada', N'Recreational Therapist', N'+7(574)759-7866', N'hauma@icloud.com', N'170-happy-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (171, N'Petersen', N'Karley', N'Rory', N' 4008 604291', N'Desoto  ', N'152 Wood Drive ', N'Gap Inc.', N'Microbiologist', N'+7(852)802-5653', N'scitext@me.com', N'171-thinking.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (172, N'Le', N'Alondra', N'Clark', N' 3059 930219', N'Jamaica  ', N'7754 Cherry Hill St.', N'Kia Motors', N'Event Planner', N'+7(342)453-0606', N'matthijs@live.com', N'172-nerd.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (173, N'Bird', N'Dorian', N'Judd', N' 5208 664172', N'Schenectady  ', N'31 Oak Valley Rd.', N'Cisco Systems, Inc.', N'Coach', N'+7(434)574-4540', N'bryam@icloud.com', N'173-in-love-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (174, N'Goodwin', N'Karley', N'Noel', N' 6338 777372', N'Middle River ', N'34 Franklin Road ', N'Home Depot', N'Radiologic Technologist', N'+7(425)783-2253', N'tellis@att.net', N'174-hypnotized.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (175, N'Davidson', N'Killian', N'Janetta', N' 8029 73589', N'Matawan  ', N'7612 Hilldale Drive ', N'Vodafone', N'Market Research Analyst', N'+7(889)449-4391', N'makarow@verizon.net', N'175-cool.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (176, N'Melton', N'Ava', N'Annabel', N' 1788 509266', N'Milford  ', N'9221 South Armstrong Ave.', N'Hewlett-Packard', N'Housekeeper', N'+7(825)301-8250', N'citadel@msn.com', N'176-shocked.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (177, N'Horton', N'Adam', N'Blake', N' 2735 502335', N'Crown Point ', N'387 Silver Spear St.', N'Hermès', N'Computer Programmer', N'+7(397)334-2086', N'jaxweb@me.com', N'177-easter.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (178, N'Singh', N'Jaydin', N'Jordon', N' 7540 934686', N'Mebane  ', N'58 th Lane ', N'Oracle Corporation', N'Secretary', N'+7(241)570-3040', N'mcsporran@aol.com', N'178-surprised-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (179, N'Mckinney', N'Lexie', N'Charles', N' 9803 515191', N'Hermitage  ', N'391 Mulberry Circle ', N'Canon', N'Bus Driver', N'+7(713)462-8265', N'tubesteak@mac.com', N'179-surprised-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (180, N'Calderon', N'Niko', N'Troy', N' 7220 353462', N'Ellenwood  ', N'298 Wakehurst Court ', N'KFC', N'Systems Analyst', N'+7(854)822-2331', N'kludge@verizon.net', N'180-surprised.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (181, N'Acevedo', N'Terrence', N'Viola', N' 9575 262338', N'Cookeville  ', N'62 Myrtle Dr. ', N'General Electric', N'Chef', N'+7(439)713-6117', N'lahvak@hotmail.com', N'181-furious.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (182, N'May', N'Madisyn', N'Byron', N' 7751 986773', N'Tucson  ', N'693 Depot Court ', N'BMW', N'Registered Nurse', N'+7(230)906-8815', N'raides@sbcglobal.net', N'182-sad-6.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (183, N'Ponce', N'Jadon', N'Doran', N' 9853 763831', N'Hallandale  ', N'9376 Theatre Drive ', N'The Walt Disney Company', N'Surveyor', N'+7(598)895-2899', N'gfxguy@aol.com', N'183-sad-5.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (184, N'Thornton', N'Jaylen', N'Tobias', N' 2868 392150', N'Freeport  ', N'7 Swanson Drive ', N'American Express', N'Urban Planner', N'+7(429)678-1872', N'krueger@msn.com', N'184-sad-4.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (185, N'Kelly', N'Brendan', N'Damien', N' 7019 883500', N'Adrian  ', N'20 Cambridge Lane ', N'Burberry', N'Middle School Teacher', N'+7(276)750-1655', N'shang@yahoo.ca', N'185-sad-3.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (186, N'Houston', N'Helena', N'Murphy', N' 1529 516117', N'Port Chester ', N'7299 East Rockledge St.', N'Pizza Hut', N'Speech-Language Pathologist', N'+7(805)953-2020', N'kalpol@comcast.net', N'186-angry-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (187, N'Moon', N'Madalyn', N'Carleen', N' 7513 42100', N'Kingston  ', N'9737 W.Sherwood Ave. ', N'H&M', N'Personal Care Aide', N'+7(611)670-2147', N'kildjean@msn.com', N'187-rich.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (188, N'Johns', N'Marcelo', N'Louisa', N' 5292 664723', N'Roy  ', N'23 Elm Rd. ', N'Heineken Brewery', N'Database administrator', N'+7(242)487-7082', N'treeves@comcast.net', N'188-sad-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (189, N'Campos', N'Jay', N'Georgina', N' 1446 216584', N'Chandler  ', N'3 Brewery St. ', N'PepsiCo', N'Database administrator', N'+7(939)641-7992', N'timtroyr@icloud.com', N'189-happy-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (190, N'Sullivan', N'Khalil', N'Rylie', N' 6353 693874', N'Newnan  ', N'8786 Galvin Dr. ', N'Bank of America', N'Landscaper & Groundskeeper', N'+7(669)482-2353', N'world@att.net', N'190-sad-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (191, N'Merritt', N'Nikhil', N'Claudia', N' 8638 615943', N'Norristown  ', N'9624 Bohemia Lane ', N'Nintendo', N'Court Reporter', N'+7(801)814-0510', N'kspiteri@icloud.com', N'191-sad.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (192, N'Melendez', N'Blaine', N'Vivian', N' 5428 298274', N'Anderson  ', N'40 Newcastle St. ', N'Johnson & Johnson', N'Bookkeeping clerk', N'+7(362)338-4199', N'rtanter@att.net', N'192-smile.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (193, N'Munoz', N'Clayton', N'Caylen', N' 8862 885055', N'Coatesville  ', N'519 Manhattan Street ', N'HSBC', N'Landscape Architect', N'+7(897)655-0021', N'twoflower@mac.com', N'193-in-love-2.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (194, N'Montgomery', N'Khalil', N'Eloise', N' 2574 326715', N'Utica  ', N'9833 East Studebaker Ave.', N'Kellogg Company', N'College Professor', N'+7(710)859-3522', N'howler@msn.com', N'194-happy.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (195, N'Medina', N'Bruce', N'Elein', N' 7843 990305', N'Pueblo  ', N'77 Shirley St. ', N'MasterCard', N'Respiratory Therapist', N'+7(612)934-2623', N'yfreund@sbcglobal.net', N'195-kiss-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (196, N'Landry', N'Lesly', N'Gregory', N' 5688 765287', N'Portage  ', N'928 Clark St. ', N'Gucci', N'Mason', N'+7(896)396-9500', N'nogin@msn.com', N'196-in-love-1.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (197, N'Hartman', N'Alyson', N'Lee', N' 7217 461000', N'Elgin  ', N'943 W.Riverview Court ', N'Mercedes-Benz', N'Veterinarian', N'+7(533)891-1018', N'onestab@live.com', N'197-in-love.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (198, N'Contreras', N'Ellen', N'Fawn', N' 1559 96165', N'Colonial Heights ', N'9501 SE.Edgemont Lane ', N'L''Oréal', N'Architect', N'+7(309)279-3798', N'lcheng@mac.com', N'198-kiss.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (199, N'Barr', N'Sofia', N'Kingston', N' 3480 736537', N'Morton Grove ', N'93 South Plumb Branch', N'KFC', N'Accountant', N'+7(483)664-9876', N'bdthomas@yahoo.com', N'199-angry.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (200, N'Wilkerson', N'Joyce', N'Payten', N' 6440 241468', N'Neenah  ', N'8058 Smith Store Street', N'General Electric', N'School Counselor', N'+7(765)461-9730', N'hoangle@optonline.net', N'200-sleepy.png', NULL)
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (201, N'Абобов', N'Олег', N'Игоревич', N'4244 424567', N'Москва', N'ул. Разумовского, д. 1', N'Бла', N'бал', N'+7(955)525-5252', N'ggs@gg.ru', N'031-crying-7.png', N'ne xochu')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (202, N'Бебров', N'Бебра', N'Бебрович', N'4256 535672', N'м', N'ул. Пестеля, д. 22', N'ООО "Бебра"', N'Добытчик', N'+7(950)525-5215', N'bebraonelove@gmail.com', N'177-easter.png', N'люблю бебру')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (203, N'Баранин', N'Владимир', N'Андреевич ', N'5425 535221', N'мос', N'ул. Самозанятая, д. 34', N'ООО "Ресофар"', N'Чистильщик', N'+7(901)532-5325', N'pesihoval@gmail.com', N'042-book.png', N'гонщик нелегальный')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (204, N'53453', N'32423', N'53453', N'534534', N'534534', N'534534', N'534534', N'534543', N'534534', N'5345345', NULL, N'')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (205, N'53453', N'32423', N'53453', N'534534', N'534534', N'534534', N'534534', N'534543', N'534534', N'5345345', NULL, N'')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (206, N'53453', N'32423', N'53453', N'534534', N'534534', N'534534', N'534534', N'534543', N'534534', N'5345345', NULL, N'')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (207, N'4234', N'434', N'4234', N'432432', N'423432', N'423432', N'423423', N'423423', N'423432', N'432423', NULL, N'')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (208, N'4234', N'434', N'4234', N'432432', N'423432', N'423432', N'423423', N'423423', N'423432', N'432423', NULL, N'')
GO
INSERT [dbo].[Drivers] ([Id], [Surname], [Name], [Middlename], [Passport], [Town], [Address], [Company], [Jobname], [Phone], [Email], [Photo], [Comment]) VALUES (209, N'4343', N'343', N'4343', N'4343', N'4343', N'4343', N'43434', N'4343', N'4343', N'34343', NULL, N'')
GO
SET IDENTITY_INSERT [dbo].[Drivers] OFF
GO
SET IDENTITY_INSERT [dbo].[License] ON 
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (1, CAST(N'2018-05-23' AS Date), CAST(N'2019-01-26' AS Date), N'5673 570962', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (2, CAST(N'2018-05-23' AS Date), CAST(N'2027-02-17' AS Date), N'2365 140143', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (3, CAST(N'2018-05-27' AS Date), CAST(N'2025-06-03' AS Date), N'8580 622744', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (4, CAST(N'2018-05-27' AS Date), CAST(N'2023-09-29' AS Date), N'5449 298803', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (5, CAST(N'2018-05-29' AS Date), CAST(N'2019-06-20' AS Date), N'1448 206175', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (6, CAST(N'2018-05-29' AS Date), CAST(N'2021-07-15' AS Date), N'9640 750187', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (7, CAST(N'2018-05-31' AS Date), CAST(N'2025-07-24' AS Date), N'7956 112224', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (8, CAST(N'2018-05-31' AS Date), CAST(N'2024-07-30' AS Date), N'2754 500373', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (9, CAST(N'2018-06-02' AS Date), CAST(N'2026-10-26' AS Date), N'5458 150506', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (10, CAST(N'2018-06-02' AS Date), CAST(N'2022-01-03' AS Date), N'1544 216181', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (11, CAST(N'2018-06-06' AS Date), CAST(N'2020-06-20' AS Date), N'7180 465917', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (12, CAST(N'2018-06-06' AS Date), CAST(N'2028-02-08' AS Date), N'6143 360486', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (13, CAST(N'2018-06-17' AS Date), CAST(N'2025-12-10' AS Date), N'8559 935502', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (14, CAST(N'2018-06-17' AS Date), CAST(N'2020-04-19' AS Date), N'6558 972443', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (15, CAST(N'2018-06-21' AS Date), CAST(N'2023-08-21' AS Date), N'9252 511894', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (16, CAST(N'2018-06-21' AS Date), CAST(N'2022-11-18' AS Date), N'6161 864298', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (17, CAST(N'2018-06-23' AS Date), CAST(N'2027-11-16' AS Date), N'5662 189864', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (18, CAST(N'2018-06-23' AS Date), CAST(N'2022-06-14' AS Date), N'8965 820437', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (19, CAST(N'2018-06-24' AS Date), CAST(N'2019-03-28' AS Date), N'5856 389246', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (20, CAST(N'2018-06-24' AS Date), CAST(N'2028-01-27' AS Date), N'7146 913695', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (21, CAST(N'2018-06-25' AS Date), CAST(N'2020-11-10' AS Date), N'7869 300408', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (22, CAST(N'2018-06-25' AS Date), CAST(N'2022-11-05' AS Date), N'9243 289084', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (23, CAST(N'2018-06-28' AS Date), CAST(N'2025-06-14' AS Date), N'3755 538095', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (24, CAST(N'2018-06-28' AS Date), CAST(N'2026-11-07' AS Date), N'3651 955678', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (25, CAST(N'2018-07-10' AS Date), CAST(N'2021-02-22' AS Date), N'1761 996073', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (26, CAST(N'2018-07-10' AS Date), CAST(N'2021-05-04' AS Date), N'7260 808111', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (27, CAST(N'2018-07-14' AS Date), CAST(N'2027-02-10' AS Date), N'5940 123897', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (28, CAST(N'2018-07-14' AS Date), CAST(N'2025-12-25' AS Date), N'8146 112671', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (29, CAST(N'2018-08-02' AS Date), CAST(N'2023-09-21' AS Date), N'7465 904246', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (30, CAST(N'2018-08-02' AS Date), CAST(N'2019-07-06' AS Date), N'7663 351410', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (31, CAST(N'2018-08-04' AS Date), CAST(N'2027-01-17' AS Date), N'6445 186021', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (32, CAST(N'2018-08-04' AS Date), CAST(N'2023-08-15' AS Date), N'8958 989847', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (33, CAST(N'2018-08-05' AS Date), CAST(N'2028-01-24' AS Date), N'2269 366545', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (34, CAST(N'2018-08-05' AS Date), CAST(N'2026-07-05' AS Date), N'7372 870584', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (35, CAST(N'2018-08-05' AS Date), CAST(N'2022-11-16' AS Date), N'7158 321618', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (36, CAST(N'2018-08-05' AS Date), CAST(N'2020-04-10' AS Date), N'8246 115947', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (37, CAST(N'2018-08-12' AS Date), CAST(N'2022-02-10' AS Date), N'3945 599900', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (38, CAST(N'2018-08-12' AS Date), CAST(N'2020-07-30' AS Date), N'8378 995967', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (39, CAST(N'2018-08-14' AS Date), CAST(N'2020-12-15' AS Date), N'1841 954617', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (40, CAST(N'2018-08-14' AS Date), CAST(N'2021-01-30' AS Date), N'9755 409226', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (41, CAST(N'2018-08-15' AS Date), CAST(N'2024-08-25' AS Date), N'9062 811272', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (42, CAST(N'2018-08-15' AS Date), CAST(N'2019-04-06' AS Date), N'8650 649001', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (43, CAST(N'2018-08-17' AS Date), CAST(N'2028-01-28' AS Date), N'3365 198629', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (44, CAST(N'2018-08-17' AS Date), CAST(N'2021-03-17' AS Date), N'5565 355405', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (45, CAST(N'2018-08-20' AS Date), CAST(N'2023-04-03' AS Date), N'3855 988267', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (46, CAST(N'2018-08-20' AS Date), CAST(N'2021-11-07' AS Date), N'5369 329732', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (47, CAST(N'2018-08-23' AS Date), CAST(N'2024-01-30' AS Date), N'2159 855910', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (48, CAST(N'2018-08-23' AS Date), CAST(N'2025-03-08' AS Date), N'8775 143198', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (49, CAST(N'2018-08-30' AS Date), CAST(N'2019-06-04' AS Date), N'6257 783363', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (50, CAST(N'2018-08-30' AS Date), CAST(N'2023-12-18' AS Date), N'4775 631972', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (51, CAST(N'2018-09-01' AS Date), CAST(N'2023-01-25' AS Date), N'3748 951841', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (52, CAST(N'2018-09-01' AS Date), CAST(N'2019-06-02' AS Date), N'1352 375141', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (53, CAST(N'2018-09-18' AS Date), CAST(N'2022-04-24' AS Date), N'9752 660653', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (54, CAST(N'2018-09-18' AS Date), CAST(N'2020-08-26' AS Date), N'1156 742127', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (55, CAST(N'2018-09-19' AS Date), CAST(N'2027-05-20' AS Date), N'6163 107404', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (56, CAST(N'2018-09-19' AS Date), CAST(N'2028-04-08' AS Date), N'2858 111698', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (57, CAST(N'2018-09-20' AS Date), CAST(N'2022-12-06' AS Date), N'9862 646552', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (58, CAST(N'2018-09-20' AS Date), CAST(N'2019-07-10' AS Date), N'1148 615982', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (59, CAST(N'2018-09-24' AS Date), CAST(N'2022-06-26' AS Date), N'7946 834138', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (60, CAST(N'2018-09-24' AS Date), CAST(N'2023-05-23' AS Date), N'9873 370750', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (61, CAST(N'2018-09-25' AS Date), CAST(N'2027-10-07' AS Date), N'4954 493125', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (62, CAST(N'2018-09-25' AS Date), CAST(N'2023-08-09' AS Date), N'8165 173583', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (63, CAST(N'2018-09-26' AS Date), CAST(N'2021-10-09' AS Date), N'8351 612336', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (64, CAST(N'2018-09-26' AS Date), CAST(N'2019-12-14' AS Date), N'8648 153332', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (65, CAST(N'2018-10-01' AS Date), CAST(N'2025-04-03' AS Date), N'5647 346550', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (66, CAST(N'2018-10-01' AS Date), CAST(N'2027-06-21' AS Date), N'7263 140335', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (67, CAST(N'2018-10-07' AS Date), CAST(N'2021-01-08' AS Date), N'9263 836793', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (68, CAST(N'2018-10-07' AS Date), CAST(N'2023-03-25' AS Date), N'4160 943122', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (69, CAST(N'2018-10-09' AS Date), CAST(N'2025-08-08' AS Date), N'8043 244787', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (70, CAST(N'2018-10-09' AS Date), CAST(N'2019-11-02' AS Date), N'7644 231262', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (71, CAST(N'2018-10-13' AS Date), CAST(N'2026-07-07' AS Date), N'7150 321250', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (72, CAST(N'2018-10-13' AS Date), CAST(N'2022-12-01' AS Date), N'6373 339944', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (73, CAST(N'2018-10-13' AS Date), CAST(N'2025-09-25' AS Date), N'4571 347925', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (74, CAST(N'2018-10-13' AS Date), CAST(N'2022-09-26' AS Date), N'9570 754064', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (75, CAST(N'2018-10-13' AS Date), CAST(N'2023-09-02' AS Date), N'9580 672343', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (76, CAST(N'2018-10-13' AS Date), CAST(N'2025-11-13' AS Date), N'3550 716066', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (77, CAST(N'2018-10-17' AS Date), CAST(N'2021-01-08' AS Date), N'8853 584291', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (78, CAST(N'2018-10-17' AS Date), CAST(N'2023-07-20' AS Date), N'8860 686627', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (79, CAST(N'2018-10-17' AS Date), CAST(N'2022-07-04' AS Date), N'4556 360521', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (80, CAST(N'2018-10-17' AS Date), CAST(N'2019-06-24' AS Date), N'4465 689019', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (81, CAST(N'2018-10-20' AS Date), CAST(N'2021-08-28' AS Date), N'3763 724944', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (82, CAST(N'2018-10-20' AS Date), CAST(N'2023-04-03' AS Date), N'3875 480183', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (83, CAST(N'2018-10-25' AS Date), CAST(N'2028-04-14' AS Date), N'9460 114388', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (84, CAST(N'2018-10-25' AS Date), CAST(N'2023-09-16' AS Date), N'8174 301902', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (85, CAST(N'2018-10-29' AS Date), CAST(N'2026-04-18' AS Date), N'1056 710506', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (86, CAST(N'2018-10-29' AS Date), CAST(N'2022-02-26' AS Date), N'5878 165905', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (87, CAST(N'2018-10-31' AS Date), CAST(N'2026-09-02' AS Date), N'5142 920836', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (88, CAST(N'2018-10-31' AS Date), CAST(N'2021-08-29' AS Date), N'5242 884090', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (89, CAST(N'2018-10-31' AS Date), CAST(N'2028-01-19' AS Date), N'3368 892304', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (90, CAST(N'2018-10-31' AS Date), CAST(N'2020-01-21' AS Date), N'1645 771049', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (91, CAST(N'2018-11-03' AS Date), CAST(N'2023-09-19' AS Date), N'7567 880032', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (92, CAST(N'2018-11-03' AS Date), CAST(N'2025-01-09' AS Date), N'5372 121874', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (93, CAST(N'2018-11-04' AS Date), CAST(N'2028-01-13' AS Date), N'4548 143560', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (94, CAST(N'2018-11-04' AS Date), CAST(N'2020-08-18' AS Date), N'5753 428231', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (95, CAST(N'2018-11-06' AS Date), CAST(N'2024-12-24' AS Date), N'8553 424706', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (96, CAST(N'2018-11-06' AS Date), CAST(N'2021-12-10' AS Date), N'1974 705660', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (97, CAST(N'2018-11-07' AS Date), CAST(N'2022-09-23' AS Date), N'4046 106016', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (98, CAST(N'2018-11-07' AS Date), CAST(N'2021-04-17' AS Date), N'5045 725156', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (99, CAST(N'2018-11-14' AS Date), CAST(N'2026-02-12' AS Date), N'6455 604567', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (100, CAST(N'2018-11-14' AS Date), CAST(N'2026-09-10' AS Date), N'6268 279896', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (101, CAST(N'2018-11-22' AS Date), CAST(N'2020-06-14' AS Date), N'3453 766347', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (102, CAST(N'2018-11-22' AS Date), CAST(N'2022-03-05' AS Date), N'6070 112930', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (103, CAST(N'2018-11-29' AS Date), CAST(N'2024-03-22' AS Date), N'4750 682392', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (104, CAST(N'2018-11-29' AS Date), CAST(N'2022-01-20' AS Date), N'1844 286148', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (105, CAST(N'2018-12-09' AS Date), CAST(N'2023-05-20' AS Date), N'2462 735138', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (106, CAST(N'2018-12-09' AS Date), CAST(N'2020-04-19' AS Date), N'3449 882286', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (107, CAST(N'2018-12-11' AS Date), CAST(N'2027-08-22' AS Date), N'2252 107095', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (108, CAST(N'2018-12-11' AS Date), CAST(N'2022-01-13' AS Date), N'4576 922777', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (109, CAST(N'2018-12-16' AS Date), CAST(N'2026-12-19' AS Date), N'4177 152038', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (110, CAST(N'2018-12-16' AS Date), CAST(N'2022-07-25' AS Date), N'3169 987280', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (111, CAST(N'2018-12-24' AS Date), CAST(N'2021-07-11' AS Date), N'8744 923347', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (112, CAST(N'2018-12-24' AS Date), CAST(N'2025-01-15' AS Date), N'5347 642355', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (113, CAST(N'2018-12-31' AS Date), CAST(N'2021-06-23' AS Date), N'5774 218810', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (114, CAST(N'2018-12-31' AS Date), CAST(N'2025-04-19' AS Date), N'7044 504351', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (115, CAST(N'2018-12-31' AS Date), CAST(N'2026-08-09' AS Date), N'4174 833772', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (116, CAST(N'2018-12-31' AS Date), CAST(N'2025-01-25' AS Date), N'6750 769897', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (117, CAST(N'2018-12-31' AS Date), CAST(N'2023-10-03' AS Date), N'9550 828023', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (118, CAST(N'2018-12-31' AS Date), CAST(N'2019-05-25' AS Date), N'7045 177463', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (119, CAST(N'2019-01-04' AS Date), CAST(N'2020-10-22' AS Date), N'8043 838745', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (120, CAST(N'2019-01-04' AS Date), CAST(N'2025-08-18' AS Date), N'4443 378433', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (121, CAST(N'2019-01-05' AS Date), CAST(N'2021-06-11' AS Date), N'8160 668818', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (122, CAST(N'2019-01-05' AS Date), CAST(N'2021-10-31' AS Date), N'8051 417594', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (123, CAST(N'2019-01-06' AS Date), CAST(N'2022-06-15' AS Date), N'7153 413313', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (124, CAST(N'2019-01-06' AS Date), CAST(N'2026-01-09' AS Date), N'5378 482016', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (125, CAST(N'2019-01-07' AS Date), CAST(N'2026-04-27' AS Date), N'9973 996427', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (126, CAST(N'2019-01-07' AS Date), CAST(N'2023-09-12' AS Date), N'9970 313651', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (127, CAST(N'2019-01-13' AS Date), CAST(N'2027-07-03' AS Date), N'5640 613073', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (128, CAST(N'2019-01-13' AS Date), CAST(N'2025-08-29' AS Date), N'5949 144483', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (129, CAST(N'2019-01-16' AS Date), CAST(N'2021-01-23' AS Date), N'3076 820189', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (130, CAST(N'2019-01-16' AS Date), CAST(N'2024-02-23' AS Date), N'2278 602987', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (131, CAST(N'2019-01-21' AS Date), CAST(N'2022-12-18' AS Date), N'6360 909624', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (132, CAST(N'2019-01-21' AS Date), CAST(N'2025-10-16' AS Date), N'5759 552536', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (133, CAST(N'2019-01-26' AS Date), CAST(N'2025-10-29' AS Date), N'8963 563046', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (134, CAST(N'2019-01-26' AS Date), CAST(N'2021-08-13' AS Date), N'8459 127815', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (135, CAST(N'2019-01-30' AS Date), CAST(N'2024-01-08' AS Date), N'8567 433962', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (136, CAST(N'2019-01-30' AS Date), CAST(N'2024-01-19' AS Date), N'4265 754604', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (137, CAST(N'2019-01-30' AS Date), CAST(N'2024-12-12' AS Date), N'9358 978442', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (138, CAST(N'2019-01-30' AS Date), CAST(N'2027-05-27' AS Date), N'9366 407687', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (139, CAST(N'2019-01-31' AS Date), CAST(N'2028-01-25' AS Date), N'9060 267003', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (140, CAST(N'2019-01-31' AS Date), CAST(N'2025-10-22' AS Date), N'6976 403371', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (141, CAST(N'2019-02-01' AS Date), CAST(N'2027-05-06' AS Date), N'1345 505754', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (142, CAST(N'2019-02-01' AS Date), CAST(N'2024-02-11' AS Date), N'4455 179449', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (143, CAST(N'2019-02-06' AS Date), CAST(N'2019-05-26' AS Date), N'7072 962735', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (144, CAST(N'2019-02-06' AS Date), CAST(N'2019-10-17' AS Date), N'6071 733903', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (145, CAST(N'2019-02-06' AS Date), CAST(N'2026-12-26' AS Date), N'3946 518387', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (146, CAST(N'2019-02-06' AS Date), CAST(N'2019-06-19' AS Date), N'2963 456353', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (147, CAST(N'2019-02-08' AS Date), CAST(N'2024-08-16' AS Date), N'5771 562291', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (148, CAST(N'2019-02-08' AS Date), CAST(N'2021-07-10' AS Date), N'4456 698959', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (149, CAST(N'2019-02-11' AS Date), CAST(N'2028-02-26' AS Date), N'7577 669648', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (150, CAST(N'2019-02-11' AS Date), CAST(N'2020-09-03' AS Date), N'5548 283081', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (151, CAST(N'2019-02-11' AS Date), CAST(N'2019-07-20' AS Date), N'6853 739807', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (152, CAST(N'2019-02-11' AS Date), CAST(N'2025-09-03' AS Date), N'4562 434160', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (153, CAST(N'2019-02-11' AS Date), CAST(N'2022-11-06' AS Date), N'1849 397861', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (154, CAST(N'2019-02-11' AS Date), CAST(N'2028-05-02' AS Date), N'2259 191387', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (155, CAST(N'2019-02-12' AS Date), CAST(N'2028-02-26' AS Date), N'5567 914299', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (156, CAST(N'2019-02-12' AS Date), CAST(N'2021-08-12' AS Date), N'8067 198658', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (157, CAST(N'2019-02-13' AS Date), CAST(N'2028-05-11' AS Date), N'7764 593417', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (158, CAST(N'2019-02-13' AS Date), CAST(N'2021-03-19' AS Date), N'8854 797589', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (159, CAST(N'2019-02-15' AS Date), CAST(N'2025-09-02' AS Date), N'7568 533909', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (160, CAST(N'2019-02-15' AS Date), CAST(N'2025-06-24' AS Date), N'2457 286769', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (161, CAST(N'2019-02-15' AS Date), CAST(N'2027-07-14' AS Date), N'9261 564412', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (162, CAST(N'2019-02-15' AS Date), CAST(N'2022-05-09' AS Date), N'5157 441335', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (163, CAST(N'2019-02-17' AS Date), CAST(N'2023-06-24' AS Date), N'5665 672465', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (164, CAST(N'2019-02-17' AS Date), CAST(N'2026-05-15' AS Date), N'9066 607418', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (165, CAST(N'2019-02-23' AS Date), CAST(N'2020-01-27' AS Date), N'3141 340685', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (166, CAST(N'2019-02-23' AS Date), CAST(N'2021-01-25' AS Date), N'9065 677102', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (167, CAST(N'2019-02-25' AS Date), CAST(N'2027-12-23' AS Date), N'2164 281543', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (168, CAST(N'2019-02-25' AS Date), CAST(N'2020-04-15' AS Date), N'8848 700693', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (169, CAST(N'2019-02-26' AS Date), CAST(N'2026-12-12' AS Date), N'5169 640455', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (170, CAST(N'2019-02-26' AS Date), CAST(N'2021-10-30' AS Date), N'4467 967541', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (171, CAST(N'2019-02-28' AS Date), CAST(N'2019-10-15' AS Date), N'1754 167771', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (172, CAST(N'2019-02-28' AS Date), CAST(N'2027-10-12' AS Date), N'8769 608724', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (173, CAST(N'2019-02-28' AS Date), CAST(N'2024-03-02' AS Date), N'5372 524117', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (174, CAST(N'2019-02-28' AS Date), CAST(N'2027-04-07' AS Date), N'5344 602449', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (175, CAST(N'2019-03-01' AS Date), CAST(N'2019-08-09' AS Date), N'3276 726052', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (176, CAST(N'2019-03-01' AS Date), CAST(N'2020-04-19' AS Date), N'2561 922773', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (177, CAST(N'2019-03-12' AS Date), CAST(N'2025-06-03' AS Date), N'9360 117922', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (178, CAST(N'2019-03-12' AS Date), CAST(N'2022-01-03' AS Date), N'8758 537518', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (179, CAST(N'2019-03-14' AS Date), CAST(N'2024-06-13' AS Date), N'1542 848910', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (180, CAST(N'2019-03-14' AS Date), CAST(N'2024-10-02' AS Date), N'5780 704668', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (181, CAST(N'2019-03-16' AS Date), CAST(N'2025-08-16' AS Date), N'4465 130693', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (182, CAST(N'2019-03-16' AS Date), CAST(N'2023-05-07' AS Date), N'7053 197719', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (183, CAST(N'2019-03-21' AS Date), CAST(N'2020-10-17' AS Date), N'5647 618832', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (184, CAST(N'2019-03-21' AS Date), CAST(N'2028-03-11' AS Date), N'1179 215392', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (185, CAST(N'2019-03-26' AS Date), CAST(N'2026-03-24' AS Date), N'2557 211673', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (186, CAST(N'2019-03-26' AS Date), CAST(N'2027-05-16' AS Date), N'4565 502480', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (187, CAST(N'2019-04-05' AS Date), CAST(N'2020-09-10' AS Date), N'3153 732792', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (188, CAST(N'2019-04-05' AS Date), CAST(N'2019-06-14' AS Date), N'2960 390525', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (189, CAST(N'2019-04-11' AS Date), CAST(N'2021-08-06' AS Date), N'1446 984592', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (190, CAST(N'2019-04-11' AS Date), CAST(N'2020-01-08' AS Date), N'6845 157412', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (191, CAST(N'2019-04-14' AS Date), CAST(N'2024-03-06' AS Date), N'8766 120201', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (192, CAST(N'2019-04-14' AS Date), CAST(N'2022-07-18' AS Date), N'2965 213322', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (193, CAST(N'2019-04-22' AS Date), CAST(N'2022-12-14' AS Date), N'7242 458530', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (194, CAST(N'2019-04-22' AS Date), CAST(N'2027-05-07' AS Date), N'4447 857224', 4)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (195, CAST(N'2019-05-07' AS Date), CAST(N'2024-11-04' AS Date), N'9645 996326', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (196, CAST(N'2019-05-07' AS Date), CAST(N'2025-10-16' AS Date), N'5274 843119', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (197, CAST(N'2019-05-14' AS Date), CAST(N'2022-07-23' AS Date), N'6965 215700', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (198, CAST(N'2019-05-14' AS Date), CAST(N'2020-11-18' AS Date), N'9566 936083', 2)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (199, CAST(N'2019-05-18' AS Date), CAST(N'2026-10-19' AS Date), N'4343 983635', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (200, CAST(N'2019-05-18' AS Date), CAST(N'2025-05-30' AS Date), N'8247 608653', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (201, CAST(N'2021-10-25' AS Date), CAST(N'2027-10-25' AS Date), N'6532 535678', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (202, CAST(N'2021-10-30' AS Date), CAST(N'2027-10-30' AS Date), N'6438 532895', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (203, CAST(N'2021-10-26' AS Date), CAST(N'2021-10-26' AS Date), N'8964 485935', 1)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (204, CAST(N'2021-01-11' AS Date), CAST(N'2027-01-11' AS Date), N'5252 535746', 3)
GO
INSERT [dbo].[License] ([Id], [LicenseDate], [ExpireDate], [License], [StatusId]) VALUES (205, CAST(N'2021-12-01' AS Date), CAST(N'2021-12-01' AS Date), N'4214 426732', 1)
GO
SET IDENTITY_INSERT [dbo].[License] OFF
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (1, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (2, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (3, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (4, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (5, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (6, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (7, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (7, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (8, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (9, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (10, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (11, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (12, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (13, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (13, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (14, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (14, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (15, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (16, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (17, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (18, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (19, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (20, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (21, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (22, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (23, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (24, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (25, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (25, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (26, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (27, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (27, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (28, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (29, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (30, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (30, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (31, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (32, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (33, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (34, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (35, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (36, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (37, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (38, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (39, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (40, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (41, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (41, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (42, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (43, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (44, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (45, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (46, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (47, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (48, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (49, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (50, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (51, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (52, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (53, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (53, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (54, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (55, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (56, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (57, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (57, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (58, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (59, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (60, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (61, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (62, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (63, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (63, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (64, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (65, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (66, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (67, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (68, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (69, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (70, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (70, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (71, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (72, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (73, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (74, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (75, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (75, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (76, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (77, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (78, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (79, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (80, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (81, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (82, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (82, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (83, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (84, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (85, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (86, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (87, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (88, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (89, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (89, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (90, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (91, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (91, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (92, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (93, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (94, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (95, 16, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (96, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (97, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (97, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (98, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (99, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (100, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (101, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (102, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (103, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (104, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (105, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (105, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (106, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (106, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (107, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (108, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (109, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (109, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (110, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (111, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (111, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (112, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (112, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (113, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (114, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (115, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (116, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (117, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (118, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (119, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (120, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (121, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (122, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (123, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (124, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (125, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (126, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (127, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (128, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (129, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (129, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (130, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (131, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (131, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (132, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (133, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (134, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (135, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (136, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (137, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (138, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (139, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (140, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (141, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (142, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (143, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (144, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (145, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (146, 12, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (146, 13, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (147, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (148, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (148, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (149, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (150, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (150, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (151, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (152, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (153, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (154, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (155, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (156, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (157, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (157, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (158, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (158, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (159, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (160, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (161, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (162, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (163, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (164, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (164, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (165, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (165, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (166, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (167, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (168, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (169, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (170, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (171, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (171, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (172, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (172, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (173, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (174, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (175, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (176, 7, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (176, 11, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (177, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (178, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (179, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (180, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (181, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (182, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (183, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (184, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (185, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (186, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (187, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (188, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (189, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (190, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (191, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (191, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (192, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (193, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (194, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (195, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (196, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (196, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (197, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (198, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (199, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (200, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (201, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (201, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (202, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (202, 12, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (203, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (203, 4, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (204, 2, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (204, 6, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (205, 1, NULL)
GO
INSERT [dbo].[LicenseOrCategories] ([LicenseId], [CategoriesId], [Nothing]) VALUES (205, 14, NULL)
GO
SET IDENTITY_INSERT [dbo].[Status] ON 
GO
INSERT [dbo].[Status] ([Id], [Name]) VALUES (1, N'Active')
GO
INSERT [dbo].[Status] ([Id], [Name]) VALUES (2, N'Expire')
GO
INSERT [dbo].[Status] ([Id], [Name]) VALUES (3, N'Paused')
GO
INSERT [dbo].[Status] ([Id], [Name]) VALUES (4, N'Withdrawn')
GO
SET IDENTITY_INSERT [dbo].[Status] OFF
GO
INSERT [dbo].[User] ([Id], [Login], [Password], [PinCode]) VALUES (1, N'Inspector', N'Inspector', 1234)
GO
ALTER TABLE [dbo].[Car]  WITH CHECK ADD  CONSTRAINT [FK_Car_CarsModel] FOREIGN KEY([ModelId])
REFERENCES [dbo].[CarsModel] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Car] CHECK CONSTRAINT [FK_Car_CarsModel]
GO
ALTER TABLE [dbo].[CarsModel]  WITH CHECK ADD  CONSTRAINT [FK_CarsModel_CarsManufacturer] FOREIGN KEY([ManufacturerId])
REFERENCES [dbo].[CarsManufacturer] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CarsModel] CHECK CONSTRAINT [FK_CarsModel_CarsManufacturer]
GO
ALTER TABLE [dbo].[ChangedStatus]  WITH CHECK ADD  CONSTRAINT [FK_ChangedStatus_Categories] FOREIGN KEY([StatusId])
REFERENCES [dbo].[Categories] ([Id])
GO
ALTER TABLE [dbo].[ChangedStatus] CHECK CONSTRAINT [FK_ChangedStatus_Categories]
GO
ALTER TABLE [dbo].[ChangedStatus]  WITH CHECK ADD  CONSTRAINT [FK_ChangedStatus_License] FOREIGN KEY([LicenseId])
REFERENCES [dbo].[License] ([Id])
GO
ALTER TABLE [dbo].[ChangedStatus] CHECK CONSTRAINT [FK_ChangedStatus_License]
GO
ALTER TABLE [dbo].[ChangedStatus]  WITH CHECK ADD  CONSTRAINT [FK_ChangedStatus_Status] FOREIGN KEY([StatusId])
REFERENCES [dbo].[Status] ([Id])
GO
ALTER TABLE [dbo].[ChangedStatus] CHECK CONSTRAINT [FK_ChangedStatus_Status]
GO
ALTER TABLE [dbo].[DriverOrCar]  WITH CHECK ADD  CONSTRAINT [FK_DriverOrCar_Car] FOREIGN KEY([CarId])
REFERENCES [dbo].[Car] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DriverOrCar] CHECK CONSTRAINT [FK_DriverOrCar_Car]
GO
ALTER TABLE [dbo].[DriverOrCar]  WITH CHECK ADD  CONSTRAINT [FK_DriverOrCar_Drivers] FOREIGN KEY([DriverId])
REFERENCES [dbo].[Drivers] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DriverOrCar] CHECK CONSTRAINT [FK_DriverOrCar_Drivers]
GO
ALTER TABLE [dbo].[DriverOrLicense]  WITH CHECK ADD  CONSTRAINT [FK_DriverOrLicense_Drivers] FOREIGN KEY([DriverId])
REFERENCES [dbo].[Drivers] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DriverOrLicense] CHECK CONSTRAINT [FK_DriverOrLicense_Drivers]
GO
ALTER TABLE [dbo].[DriverOrLicense]  WITH CHECK ADD  CONSTRAINT [FK_DriverOrLicense_License] FOREIGN KEY([LicenseId])
REFERENCES [dbo].[License] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DriverOrLicense] CHECK CONSTRAINT [FK_DriverOrLicense_License]
GO
ALTER TABLE [dbo].[License]  WITH CHECK ADD  CONSTRAINT [FK_License_Status] FOREIGN KEY([StatusId])
REFERENCES [dbo].[Status] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[License] CHECK CONSTRAINT [FK_License_Status]
GO
ALTER TABLE [dbo].[LicenseOrCategories]  WITH CHECK ADD  CONSTRAINT [FK_LicenseOrCategories_Categories] FOREIGN KEY([CategoriesId])
REFERENCES [dbo].[Categories] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LicenseOrCategories] CHECK CONSTRAINT [FK_LicenseOrCategories_Categories]
GO
ALTER TABLE [dbo].[LicenseOrCategories]  WITH CHECK ADD  CONSTRAINT [FK_LicenseOrCategories_License] FOREIGN KEY([LicenseId])
REFERENCES [dbo].[License] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LicenseOrCategories] CHECK CONSTRAINT [FK_LicenseOrCategories_License]
GO
USE [master]
GO
ALTER DATABASE [Drivers] SET  READ_WRITE 
GO
