namespace Auto1Var
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DriverOrLicense")]
    public partial class DriverOrLicense
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int DriverId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int LicenseId { get; set; }

        [StringLength(5)]
        public string Nothing { get; set; }

        public virtual Drivers Drivers { get; set; }

        public virtual License License { get; set; }
    }
}
