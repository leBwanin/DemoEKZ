using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Auto1Var
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Car> Car { get; set; }
        public virtual DbSet<CarsManufacturer> CarsManufacturer { get; set; }
        public virtual DbSet<CarsModel> CarsModel { get; set; }
        public virtual DbSet<Categories> Categories { get; set; }
        public virtual DbSet<ChangedStatus> ChangedStatus { get; set; }
        public virtual DbSet<DriverOrCar> DriverOrCar { get; set; }
        public virtual DbSet<DriverOrLicense> DriverOrLicense { get; set; }
        public virtual DbSet<Drivers> Drivers { get; set; }
        public virtual DbSet<License> License { get; set; }
        public virtual DbSet<LicenseOrCategories> LicenseOrCategories { get; set; }
        public virtual DbSet<Status> Status { get; set; }
        public virtual DbSet<User> User { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CarsManufacturer>()
                .HasMany(e => e.CarsModel)
                .WithRequired(e => e.CarsManufacturer)
                .HasForeignKey(e => e.ManufacturerId);

            modelBuilder.Entity<CarsModel>()
                .HasMany(e => e.Car)
                .WithRequired(e => e.CarsModel)
                .HasForeignKey(e => e.ModelId);

            modelBuilder.Entity<Categories>()
                .HasMany(e => e.ChangedStatus)
                .WithRequired(e => e.Categories)
                .HasForeignKey(e => e.StatusId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Drivers>()
                .HasMany(e => e.DriverOrCar)
                .WithRequired(e => e.Drivers)
                .HasForeignKey(e => e.DriverId);

            modelBuilder.Entity<Drivers>()
                .HasMany(e => e.DriverOrLicense)
                .WithRequired(e => e.Drivers)
                .HasForeignKey(e => e.DriverId);

            modelBuilder.Entity<License>()
                .HasMany(e => e.ChangedStatus)
                .WithRequired(e => e.License)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Status>()
                .HasMany(e => e.ChangedStatus)
                .WithRequired(e => e.Status)
                .WillCascadeOnDelete(false);
        }
    }
}
