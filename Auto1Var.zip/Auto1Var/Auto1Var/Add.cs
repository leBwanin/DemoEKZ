﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auto1Var
{
    public partial class Add : Form
    {
        Model1 db = new Model1();
        public Add()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, EventArgs e) // кнопка сохранения
        {
            if (FamilyBox.Text == "" || PassportBox.Text == "" || AddressBox.Text == ""
                 || JobBox.Text == "" || JobNameBox.Text == "" || PhoneBox.Text == "" || emailBox.Text == "" || MiddleBox.Text == "")
            {
                MessageBox.Show("Нужно ввести все требуемые данные"); // вывод на экран текста 
                return;
            }
            Drivers drivers = new Drivers();
            drivers.Surname = MiddleBox.Text;
            drivers.Name = FamilyBox.Text;
            drivers.Middlename = MiddleBox.Text;
            drivers.Passport = PassportBox.Text;
            drivers.Town = AddressBox.Text;
            drivers.Address = AddressBox.Text;
            drivers.Company = JobBox.Text;
            drivers.Jobname = JobNameBox.Text;
            drivers.Phone = PhoneBox.Text;
            drivers.Email = emailBox.Text;
            drivers.Comment = CommentBox.Text;
            db.Drivers.Add(drivers);
            try
            {
                db.SaveChanges();
                MessageBox.Show("Данные сохранены"); // вывод на экран, если данные сохранились

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // вывод ошибки на экран
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Exit_Button_Click(object sender, EventArgs e)
        {
            this.Close(); // закрытие формы
            Form2 form2 = new Form2();
            form2.Show(); // открытие формы
        }

        private void PassportBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
