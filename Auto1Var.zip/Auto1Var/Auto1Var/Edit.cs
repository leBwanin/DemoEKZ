﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auto1Var
{
    public partial class Edit : Form
    {
        public Model1 db { get; set; }
        public Drivers dr { get; set; }
        public Edit()
        {
            InitializeComponent();
        }

        private void Edit_Load(object sender, EventArgs e)
        {

        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show(); // показывает форму
            this.Hide(); // скрываем прошлую форму 
        }

        private void FamilyBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            MiddleBox.Text = dr.Surname;
            FamilyBox.Text = dr.Name;
            MiddleBox.Text = dr.Middlename;
            PassportBox.Text = dr.Passport;
            AddressBox.Text = dr.Town;
            AddressBox.Text = dr.Address = AddressBox.Text;
            JobBox.Text = dr.Company;
            JobNameBox.Text = dr.Jobname;
            PhoneBox.Text = dr.Phone;
            emailBox.Text = dr.Email;
            
        }
    }
}
