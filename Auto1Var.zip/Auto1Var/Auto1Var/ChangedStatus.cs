namespace Auto1Var
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ChangedStatus
    {
        public int Id { get; set; }

        public int LicenseId { get; set; }

        public int StatusId { get; set; }

        [Required]
        public string Comment { get; set; }

        public virtual Categories Categories { get; set; }

        public virtual License License { get; set; }

        public virtual Status Status { get; set; }
    }
}
