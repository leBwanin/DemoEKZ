﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auto1Var
{
    public partial class Form1 : Form
    {
        public static Form1 Forma { get; set; }
        public static User User { get; set; }
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "inspector" || textBox2.Text != "inspector") // проверяет логин и пароль
            {
                MessageBox.Show("Введите логин и пароль!");  // если пароль и логин незаполнены или неверно заполены
                return;
            }
            if (textBox1.Text == "inspector" || textBox2.Text == "inspector")
            {
                Form2 form2 = new Form2();
                form2.Show(); // показывает форму
                this.Hide();  // скрывает форму Авторизации
            }
        }
    }
}
